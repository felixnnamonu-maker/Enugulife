import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue, Timestamp, Transaction, DocumentReference } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";
import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";
import * as C from "./catalog";

initializeApp();
const db = getFirestore();
db.settings({ ignoreUndefinedProperties: true });
setGlobalOptions({ region: "us-central1", maxInstances: 20 });

// ---------------------------------------------------------------- types
interface Account {
  cash: number;
  bank: number;
  needs: C.Needs;
  needsAt: number;
  xp: number;
  jobId: string | null;
  jobXp: number;
  shift: { endsAt: number; jobId: string } | null;
  busyUntil: number;
  busyReason: string;
  travel: { to: string; arriveAt: number } | null;
  homeId: string;
  rentPaidUntil: number;
  daily: { day: string; counts: Record<string, number>; claimed: string[] };
  dailyOut: { day: string; amount: number };
  stats: { shifts: number; trips: number; purchases: number; transfersSent: number; messages: number; earned: number };
  blocked: string[];
  msgTimes: number[];
  lastMsg: { text: string; at: number } | null;
  lastReportAt: number;
  lastTransferAt: number;
  banned: boolean;
  createdAt: number;
}
interface Pub {
  username: string;
  usernameLower: string;
  displayName: string;
  avatar: C.AvatarCfg;
  presentation: string;
  personality: string;
  bio: string;
  status: string;
  location: string; // location id, or "road" while travelling
  level: number;
  xp: number;
  netWorth: number;
  jobTitle: string | null;
  lastActive: number;
  createdAt: number;
}
interface Ctx {
  uid: string;
  aRef: DocumentReference;
  pRef: DocumentReference;
  acc: Account;
  pub: Pub;
  t: number;
}

// ---------------------------------------------------------------- helpers
const RESERVED = new Set(["admin", "administrator", "moderator", "mod", "support", "enugulife", "system", "staff", "official", "root", "null", "undefined"]);

function uidOf(req: CallableRequest): string {
  if (!req.auth) throw new HttpsError("unauthenticated", "Please sign in.");
  return req.auth.uid;
}
function bad(msg: string): never {
  throw new HttpsError("invalid-argument", msg);
}
function precond(msg: string): never {
  throw new HttpsError("failed-precondition", msg);
}
function int(v: unknown, min: number, max: number, label: string): number {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) bad(`${label} must be a whole number between ${min} and ${max}.`);
  return n;
}
function str(v: unknown, min: number, max: number, label: string): string {
  if (typeof v !== "string") bad(`${label} is required.`);
  const s = (v as string).replace(/\s+/g, " ").trim();
  if (s.length < min || s.length > max) bad(`${label} must be ${min}-${max} characters.`);
  return s;
}
function optStr(v: unknown, max: number, label: string): string {
  if (v === undefined || v === null || v === "") return "";
  return str(v, 0, max, label);
}
function oneOf(v: unknown, list: string[], label: string): string {
  if (typeof v !== "string" || !list.includes(v)) bad(`Invalid ${label}.`);
  return v as string;
}
function cleanAvatar(a: any, outfit = "casual"): C.AvatarCfg {
  return {
    skin: int(a?.skin ?? 2, 0, C.SKIN_TONES.length - 1, "Skin tone"),
    hair: int(a?.hair ?? 0, 0, C.HAIR_STYLES.length - 1, "Hairstyle"),
    hairColor: int(a?.hairColor ?? 0, 0, C.HAIR_COLORS.length - 1, "Hair colour"),
    outfit,
  };
}

async function load(tx: Transaction, uid: string): Promise<Ctx> {
  const aRef = db.doc(`accounts/${uid}`);
  const pRef = db.doc(`players/${uid}`);
  const [a, p] = await Promise.all([tx.get(aRef), tx.get(pRef)]);
  if (!a.exists || !p.exists) precond("Create your character first.");
  const acc = a.data() as Account;
  const pub = p.data() as Pub;
  if (acc.banned) throw new HttpsError("permission-denied", "This account has been suspended.");
  const t = Date.now();
  acc.needs = C.applyDecay(acc.needs, acc.needsAt, t);
  acc.needsAt = t;
  if (acc.travel && t >= acc.travel.arriveAt) {
    pub.location = acc.travel.to;
    acc.travel = null;
  }
  const day = C.lagosDay(t);
  if (acc.daily.day !== day) acc.daily = { day, counts: {}, claimed: [] };
  if (acc.dailyOut.day !== day) acc.dailyOut = { day, amount: 0 };
  return { uid, aRef, pRef, acc, pub, t };
}

function save(tx: Transaction, c: Ctx) {
  const { acc, pub } = c;
  pub.netWorth = acc.cash + acc.bank;
  pub.level = C.levelFromXp(acc.xp);
  pub.xp = acc.xp;
  const job = acc.jobId ? C.JOB_BY_ID[acc.jobId] : null;
  pub.jobTitle = job ? job.ranks[C.rankForXp(job, acc.jobXp)].title : null;
  pub.lastActive = c.t;
  tx.set(c.aRef, acc);
  tx.set(c.pRef, pub);
}

function assertFree(c: Ctx) {
  if (c.acc.busyUntil > c.t) {
    const s = Math.ceil((c.acc.busyUntil - c.t) / 1000);
    precond(`You're busy (${c.acc.busyReason}) for another ${s}s.`);
  }
}
function setBusy(c: Ctx, seconds: number, reason: string) {
  c.acc.busyUntil = c.t + seconds * 1000;
  c.acc.busyReason = reason;
}
function bump(c: Ctx, metric: string, n = 1) {
  c.acc.daily.counts[metric] = (c.acc.daily.counts[metric] || 0) + n;
}

function notify(tx: Transaction, uid: string, type: string, title: string, body: string) {
  tx.set(db.collection(`notifications/${uid}/items`).doc(), {
    type,
    title,
    body,
    read: false,
    at: Date.now(),
    expireAt: Timestamp.fromMillis(Date.now() + 30 * 86400000),
  });
}

interface LedgerEntry {
  type: string;
  amount: number;
  participants: string[];
  from?: string | null;
  to?: string | null;
  fromUsername?: string | null;
  toUsername?: string | null;
  note?: string;
  account?: "cash" | "bank";
}
function ledger(tx: Transaction, e: LedgerEntry, id?: string): string {
  const ref = id ? db.collection("transactions").doc(id) : db.collection("transactions").doc();
  tx.set(ref, { ...e, status: "completed", at: Date.now() });
  return ref.id;
}

async function ownsAny(tx: Transaction, uid: string, itemIds: string[]): Promise<boolean> {
  if (!itemIds.length) return false;
  const snaps = await Promise.all(itemIds.map((i) => tx.get(db.doc(`accounts/${uid}/inventory/${i}`))));
  return snaps.some((s) => s.exists && (s.data()?.qty ?? 0) > 0);
}

// ---------------------------------------------------------------- account / profile
export const createPlayer = onCall(async (req) => {
  const uid = uidOf(req);
  const d = req.data ?? {};
  const username = str(d.username, 3, 16, "Username");
  if (!/^[A-Za-z][A-Za-z0-9_]{2,15}$/.test(username)) bad("Username must start with a letter and use only letters, numbers or underscores.");
  const lower = username.toLowerCase();
  if (RESERVED.has(lower)) bad("That username is reserved.");
  const displayName = str(d.displayName, 2, 24, "Display name");
  const avatar = cleanAvatar(d.avatar);
  const presentation = oneOf(d.presentation ?? "Neutral", C.PRESENTATIONS, "presentation");
  const personality = oneOf(d.personality ?? "Chill", C.PERSONALITIES, "personality");
  const bio = optStr(d.bio, 300, "Background story");
  const t = Date.now();

  await db.runTransaction(async (tx) => {
    const uRef = db.doc(`usernames/${lower}`);
    const pRef = db.doc(`players/${uid}`);
    const aRef = db.doc(`accounts/${uid}`);
    const [u, p] = await Promise.all([tx.get(uRef), tx.get(pRef)]);
    if (p.exists) throw new HttpsError("already-exists", "You already have a character.");
    if (u.exists) throw new HttpsError("already-exists", "That username is taken.");
    const acc: Account = {
      cash: C.START_CASH,
      bank: C.START_BANK,
      needs: { ...C.DEFAULT_NEEDS },
      needsAt: t,
      xp: 0,
      jobId: null,
      jobXp: 0,
      shift: null,
      busyUntil: 0,
      busyReason: "",
      travel: null,
      homeId: C.START_HOME,
      rentPaidUntil: t + C.START_RENT_DAYS * 86400000,
      daily: { day: C.lagosDay(t), counts: {}, claimed: [] },
      dailyOut: { day: C.lagosDay(t), amount: 0 },
      stats: { shifts: 0, trips: 0, purchases: 0, transfersSent: 0, messages: 0, earned: 0 },
      blocked: [],
      msgTimes: [],
      lastMsg: null,
      lastReportAt: 0,
      lastTransferAt: 0,
      banned: false,
      createdAt: t,
    };
    const pub: Pub = {
      username,
      usernameLower: lower,
      displayName,
      avatar,
      presentation,
      personality,
      bio,
      status: "",
      location: C.START_LOCATION,
      level: 1,
      xp: 0,
      netWorth: acc.cash + acc.bank,
      jobTitle: null,
      lastActive: t,
      createdAt: t,
    };
    tx.set(uRef, { uid, at: t });
    tx.set(aRef, acc);
    tx.set(pRef, pub);
    notify(tx, uid, "welcome", "Welcome to Enugu Life", "You start in Uwani with a room, some cash and a bank balance. Find a job and make your story.");
  });
  return { ok: true };
});

export const updateProfile = onCall(async (req) => {
  const uid = uidOf(req);
  const d = req.data ?? {};
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    let outfit = c.pub.avatar.outfit;
    if (d.avatar?.outfit !== undefined) {
      outfit = oneOf(d.avatar.outfit, C.OUTFITS, "outfit");
      if (outfit !== "casual") {
        const ids = C.ITEMS.filter((i) => i.outfit === outfit).map((i) => i.id);
        if (!(await ownsAny(tx, uid, ids))) precond("You don't own that outfit yet. Buy it in a shop first.");
      }
    }
    if (d.displayName !== undefined) c.pub.displayName = str(d.displayName, 2, 24, "Display name");
    if (d.bio !== undefined) c.pub.bio = optStr(d.bio, 300, "Background story");
    if (d.status !== undefined) c.pub.status = optStr(d.status, 80, "Status");
    if (d.personality !== undefined) c.pub.personality = oneOf(d.personality, C.PERSONALITIES, "personality");
    if (d.presentation !== undefined) c.pub.presentation = oneOf(d.presentation, C.PRESENTATIONS, "presentation");
    if (d.avatar) c.pub.avatar = cleanAvatar({ ...c.pub.avatar, ...d.avatar }, outfit);
    save(tx, c);
  });
  return { ok: true };
});

export const heartbeat = onCall(async (req) => {
  const uid = uidOf(req);
  const snap = await db.doc(`accounts/${uid}`).get();
  if (!snap.exists) return { ok: false };
  const acc = snap.data() as Account;
  if (acc.banned) throw new HttpsError("permission-denied", "This account has been suspended.");
  if (acc.travel && Date.now() >= acc.travel.arriveAt) {
    await db.runTransaction(async (tx) => {
      const c = await load(tx, uid);
      save(tx, c);
    });
  } else {
    await db.doc(`players/${uid}`).update({ lastActive: Date.now() });
  }
  return { ok: true };
});

export const requestAccountDeletion = onCall(async (req) => {
  const uid = uidOf(req);
  await db.doc(`deletionRequests/${uid}`).set({ uid, at: Date.now(), status: "pending" });
  return { ok: true };
});

// ---------------------------------------------------------------- travel
export const travel = onCall(async (req) => {
  const uid = uidOf(req);
  const to = oneOf(req.data?.to, C.LOCATIONS.map((l) => l.id), "destination");
  const mode = C.TRANSPORT_BY_ID[oneOf(req.data?.mode, C.TRANSPORT.map((m) => m.id), "transport")];
  return db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    assertFree(c);
    if (c.pub.location === to) precond("You're already there.");
    const hr = C.lagosHour(c.t);
    if (hr < mode.fromHour || hr >= mode.toHour) precond(`${mode.name} isn't running right now.`);
    const q = C.tripQuote(c.pub.location, to, mode);
    if (c.acc.cash < q.cost) precond("Not enough cash for this fare. Withdraw some from the Bank.");
    if (c.acc.needs.energy < Math.max(q.energy, 1)) precond("You're too tired for this trip. Rest or pick another transport.");
    c.acc.cash -= q.cost;
    c.acc.needs.energy = C.clamp(c.acc.needs.energy - q.energy);
    c.acc.travel = { to, arriveAt: c.t + q.seconds * 1000 };
    setBusy(c, q.seconds, `Travelling to ${C.LOCATION_BY_ID[to].name}`);
    c.pub.location = "road";
    c.acc.stats.trips += 1;
    bump(c, "travel");
    if (q.cost > 0) ledger(tx, { type: "transport", amount: q.cost, participants: [uid], from: uid, note: `${mode.name} to ${C.LOCATION_BY_ID[to].name}`, account: "cash" });
    save(tx, c);
    return { seconds: q.seconds, cost: q.cost };
  });
});

// ---------------------------------------------------------------- jobs
export const applyForJob = onCall(async (req) => {
  const uid = uidOf(req);
  const job = C.JOB_BY_ID[oneOf(req.data?.jobId, C.JOBS.map((j) => j.id), "job")];
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    assertFree(c);
    if (c.acc.shift) precond("Finish your current shift first.");
    if (c.acc.jobId === job.id) precond("You already work here.");
    if (C.levelFromXp(c.acc.xp) < job.reqLevel) precond(`You need player level ${job.reqLevel} for this job.`);
    c.acc.jobId = job.id;
    c.acc.jobXp = 0;
    notify(tx, uid, "job", "Job offer accepted", `You're now a ${job.ranks[0].title} at ${job.employer}. Go to ${C.LOCATION_BY_ID[job.locationId].name} to start a shift.`);
    save(tx, c);
  });
  return { ok: true };
});

export const quitJob = onCall(async (req) => {
  const uid = uidOf(req);
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    if (c.acc.shift) precond("Finish your current shift first.");
    c.acc.jobId = null;
    c.acc.jobXp = 0;
    save(tx, c);
  });
  return { ok: true };
});

export const startShift = onCall(async (req) => {
  const uid = uidOf(req);
  return db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    assertFree(c);
    if (c.acc.shift) precond("You're already on shift.");
    const job = c.acc.jobId ? C.JOB_BY_ID[c.acc.jobId] : null;
    if (!job) precond("You don't have a job yet.");
    if (c.pub.location !== job!.locationId) precond(`Your workplace is in ${C.LOCATION_BY_ID[job!.locationId].name}.`);
    if (c.acc.needs.energy < job!.energyCost) precond("You're too tired to work. Rest first.");
    if (c.acc.needs.hunger < job!.hungerCost) precond("You're too hungry to work. Eat something.");
    c.acc.needs.energy = C.clamp(c.acc.needs.energy - job!.energyCost);
    c.acc.needs.hunger = C.clamp(c.acc.needs.hunger - job!.hungerCost);
    c.acc.shift = { endsAt: c.t + job!.shiftSeconds * 1000, jobId: job!.id };
    setBusy(c, job!.shiftSeconds, "On shift");
    save(tx, c);
    return { seconds: job!.shiftSeconds };
  });
});

export const finishShift = onCall(async (req) => {
  const uid = uidOf(req);
  return db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    const sh = c.acc.shift;
    if (!sh) precond("You're not on a shift.");
    if (c.t < sh!.endsAt) precond(`Your shift ends in ${Math.ceil((sh!.endsAt - c.t) / 1000)}s.`);
    const job = C.JOB_BY_ID[sh!.jobId];
    const oldRank = C.rankForXp(job, c.acc.jobXp);
    const pay = job.ranks[oldRank].pay;
    c.acc.jobXp += C.JOB_XP_PER_SHIFT;
    const oldLevel = C.levelFromXp(c.acc.xp);
    c.acc.xp += C.PLAYER_XP_PER_SHIFT;
    c.acc.bank += pay;
    c.acc.stats.shifts += 1;
    c.acc.stats.earned += pay;
    c.acc.shift = null;
    c.acc.busyUntil = 0;
    c.acc.busyReason = "";
    bump(c, "work");
    ledger(tx, { type: "salary", amount: pay, participants: [uid], to: uid, note: `${job.ranks[oldRank].title}, ${job.employer}`, account: "bank" });
    notify(tx, uid, "salary", "Salary paid", `${C.CURRENCY}${pay.toLocaleString("en-NG")} was paid into your bank account.`);
    const newRank = C.rankForXp(job, c.acc.jobXp);
    if (newRank > oldRank) notify(tx, uid, "promotion", "Promotion!", `You've been promoted to ${job.ranks[newRank].title}.`);
    if (C.levelFromXp(c.acc.xp) > oldLevel) notify(tx, uid, "level", "Level up", `You reached player level ${C.levelFromXp(c.acc.xp)}.`);
    save(tx, c);
    return { pay, promoted: newRank > oldRank };
  });
});

// ---------------------------------------------------------------- shopping & items
export const buyItem = onCall(async (req) => {
  const uid = uidOf(req);
  const item = C.ITEM_BY_ID[oneOf(req.data?.itemId, C.ITEMS.map((i) => i.id), "item")];
  const qty = int(req.data?.qty ?? 1, 1, 20, "Quantity");
  await db.runTransaction(async (tx) => {
    const invRef = db.doc(`accounts/${uid}/inventory/${item.id}`);
    const [c, inv] = await Promise.all([load(tx, uid), tx.get(invRef)]);
    assertFree(c);
    if (!item.soldAt.includes(c.pub.location)) precond("This item isn't sold here.");
    const cost = item.price * qty;
    if (c.acc.cash < cost) precond("Not enough cash. Withdraw from the Bank first.");
    c.acc.cash -= cost;
    c.acc.stats.purchases += qty;
    bump(c, "buy", qty);
    tx.set(invRef, { itemId: item.id, qty: (inv.exists ? inv.data()!.qty : 0) + qty });
    ledger(tx, { type: "purchase", amount: cost, participants: [uid], from: uid, note: `${qty} x ${item.name}`, account: "cash" });
    save(tx, c);
  });
  return { ok: true };
});

export const useItem = onCall(async (req) => {
  const uid = uidOf(req);
  const item = C.ITEM_BY_ID[oneOf(req.data?.itemId, C.ITEMS.map((i) => i.id), "item")];
  await db.runTransaction(async (tx) => {
    const invRef = db.doc(`accounts/${uid}/inventory/${item.id}`);
    const [c, inv] = await Promise.all([load(tx, uid), tx.get(invRef)]);
    const have = inv.exists ? inv.data()!.qty : 0;
    if (have < 1) precond("You don't have that item.");
    if (item.effects) {
      c.acc.needs = C.applyEffects(c.acc.needs, item.effects);
      if (have === 1) tx.delete(invRef);
      else tx.set(invRef, { itemId: item.id, qty: have - 1 });
    } else if (item.outfit) {
      c.pub.avatar = { ...c.pub.avatar, outfit: item.outfit };
    } else {
      precond("This item works automatically while you own it.");
    }
    save(tx, c);
  });
  return { ok: true };
});

export const doActivity = onCall(async (req) => {
  const uid = uidOf(req);
  const act = C.ACTIVITY_BY_ID[oneOf(req.data?.activityId, C.ACTIVITIES.map((a) => a.id), "activity")];
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    assertFree(c);
    const home = C.HOME_BY_ID[c.acc.homeId];
    if (act.home) {
      if (c.pub.location !== home.locationId) precond(`Go home first (${C.LOCATION_BY_ID[home.locationId].name}).`);
      if (c.acc.rentPaidUntil <= c.t) precond("Your rent has expired. Renew it in the Bag > Home tab.");
    } else if (!act.locations?.includes(c.pub.location)) {
      precond("You can't do that here.");
    }
    if (act.needsItem && !(await ownsAny(tx, uid, [act.needsItem]))) precond(`You need a ${C.ITEM_BY_ID[act.needsItem].name}.`);
    let fx = { ...act.effects };
    if (act.id === "sleep") {
      const beds = C.ITEMS.filter((i) => i.sleepBonus).map((i) => i.id);
      const snaps = await Promise.all(beds.map((i) => tx.get(db.doc(`accounts/${uid}/inventory/${i}`))));
      let bonus = 0;
      snaps.forEach((s, i) => {
        if (s.exists && (s.data()?.qty ?? 0) > 0) bonus = Math.max(bonus, C.ITEM_BY_ID[beds[i]].sleepBonus ?? 0);
      });
      fx.energy = Math.round((act.effects.energy ?? 0) * home.sleepMult * (1 + bonus / 100));
    }
    if (c.acc.cash < act.cost) precond("Not enough cash.");
    c.acc.cash -= act.cost;
    c.acc.needs = C.applyEffects(c.acc.needs, fx);
    c.acc.xp += act.xp;
    setBusy(c, act.seconds, act.name);
    bump(c, "activity");
    if (act.cost > 0) ledger(tx, { type: "service", amount: act.cost, participants: [uid], from: uid, note: act.name, account: "cash" });
    save(tx, c);
  });
  return { ok: true };
});

export const rentHome = onCall(async (req) => {
  const uid = uidOf(req);
  const home = C.HOME_BY_ID[oneOf(req.data?.homeId, C.HOMES.map((h) => h.id), "home")];
  const weeks = int(req.data?.weeks ?? 1, 1, 4, "Weeks");
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    const cost = home.weeklyRent * weeks;
    if (c.acc.bank < cost) precond("Not enough money in your bank account.");
    c.acc.bank -= cost;
    if (c.acc.homeId === home.id) c.acc.rentPaidUntil = Math.max(c.t, c.acc.rentPaidUntil) + weeks * 7 * 86400000;
    else {
      c.acc.homeId = home.id;
      c.acc.rentPaidUntil = c.t + weeks * 7 * 86400000;
    }
    ledger(tx, { type: "rent", amount: cost, participants: [uid], from: uid, note: `${weeks} week(s), ${home.name}`, account: "bank" });
    save(tx, c);
  });
  return { ok: true };
});

// ---------------------------------------------------------------- bank & transfers
export const bankMove = onCall(async (req) => {
  const uid = uidOf(req);
  const dir = oneOf(req.data?.direction, ["deposit", "withdraw"], "direction");
  const amount = int(req.data?.amount, 1, 10000000, "Amount");
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    if (dir === "deposit") {
      if (c.acc.cash < amount) precond("Not enough cash.");
      c.acc.cash -= amount;
      c.acc.bank += amount;
    } else {
      if (c.acc.bank < amount) precond("Not enough money in your bank account.");
      c.acc.bank -= amount;
      c.acc.cash += amount;
    }
    ledger(tx, { type: dir === "deposit" ? "deposit" : "withdrawal", amount, participants: [uid], note: dir === "deposit" ? "Cash to bank" : "Bank to cash" });
    save(tx, c);
  });
  return { ok: true };
});

export const sendMoney = onCall(async (req) => {
  const uid = uidOf(req);
  const d = req.data ?? {};
  const toName = str(d.toUsername, 3, 16, "Recipient").toLowerCase();
  const amount = int(d.amount, 1, C.MAX_TRANSFER, "Amount");
  const note = optStr(d.note, 80, "Note");
  const key = typeof d.key === "string" ? d.key : "";
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(key)) bad("Missing request key. Please try again.");
  const uSnap = await db.doc(`usernames/${toName}`).get();
  if (!uSnap.exists) throw new HttpsError("not-found", "No player with that username.");
  const toUid: string = uSnap.data()!.uid;
  if (toUid === uid) bad("You can't send money to yourself.");

  return db.runTransaction(async (tx) => {
    const idemRef = db.doc(`idempotency/${uid}_${key}`);
    const rAcc = db.doc(`accounts/${toUid}`);
    const rPub = db.doc(`players/${toUid}`);
    const [c, idem, ra, rp] = await Promise.all([load(tx, uid), tx.get(idemRef), tx.get(rAcc), tx.get(rPub)]);
    if (idem.exists) return idem.data()!.result; // duplicate submission: return the original result
    if (!ra.exists || !rp.exists) throw new HttpsError("not-found", "That player no longer exists.");
    const racc = ra.data() as Account;
    if (racc.banned) precond("That player can't receive transfers right now.");
    if (racc.blocked.includes(uid)) precond("That player can't receive transfers from you.");
    if (c.t - c.acc.lastTransferAt < 3000) precond("Slow down a little before sending again.");
    if (c.acc.bank < amount) precond("Not enough money in your bank account.");
    if (c.acc.dailyOut.amount + amount > C.MAX_DAILY_TRANSFER) precond("This would exceed your daily transfer limit.");
    c.acc.bank -= amount;
    c.acc.dailyOut.amount += amount;
    c.acc.lastTransferAt = c.t;
    c.acc.stats.transfersSent += 1;
    const toUsername = (rp.data() as Pub).username;
    const txId = ledger(tx, { type: "transfer", amount, participants: [uid, toUid], from: uid, to: toUid, fromUsername: c.pub.username, toUsername, note, account: "bank" });
    tx.update(rAcc, { bank: FieldValue.increment(amount) });
    tx.update(rPub, { netWorth: FieldValue.increment(amount) });
    notify(tx, toUid, "transfer", "You received money", `${c.pub.username} sent you ${C.CURRENCY}${amount.toLocaleString("en-NG")}${note ? ` — "${note}"` : ""}.`);
    const result = { txId, amount, to: toUsername };
    tx.set(idemRef, { result, at: c.t, expireAt: Timestamp.fromMillis(c.t + 7 * 86400000) });
    save(tx, c);
    return result;
  });
});

// ---------------------------------------------------------------- missions
export const claimMission = onCall(async (req) => {
  const uid = uidOf(req);
  const m = C.MISSION_BY_ID[oneOf(req.data?.missionId, C.DAILY_MISSIONS.map((x) => x.id), "mission")];
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    if (c.acc.daily.claimed.includes(m.id)) precond("Already claimed today.");
    if ((c.acc.daily.counts[m.metric] || 0) < m.target) precond("Mission not complete yet.");
    c.acc.daily.claimed.push(m.id);
    c.acc.bank += m.cash;
    c.acc.xp += m.xp;
    c.acc.stats.earned += m.cash;
    ledger(tx, { type: "mission", amount: m.cash, participants: [uid], to: uid, note: m.title, account: "bank" });
    notify(tx, uid, "mission", "Mission complete", `${m.title}: +${C.CURRENCY}${m.cash.toLocaleString("en-NG")} and ${m.xp} XP.`);
    save(tx, c);
  });
  return { ok: true };
});

// ---------------------------------------------------------------- chat
export const sendMessage = onCall(async (req) => {
  const uid = uidOf(req);
  const channel = oneOf(req.data?.channel, ["location", "dm"], "channel");
  const text = str(req.data?.text, 1, 280, "Message");
  const toUid = channel === "dm" ? str(req.data?.to, 5, 128, "Recipient") : "";
  await db.runTransaction(async (tx) => {
    const extra =
      channel === "dm"
        ? await Promise.all([tx.get(db.doc(`friends/${uid}/list/${toUid}`)), tx.get(db.doc(`accounts/${toUid}`))])
        : null;
    const c = await load(tx, uid);
    c.acc.msgTimes = (c.acc.msgTimes || []).filter((x) => c.t - x < 60000);
    if (c.acc.msgTimes.length >= 15) precond("You're sending messages too quickly. Wait a moment.");
    if (c.acc.msgTimes.length && c.t - c.acc.msgTimes[c.acc.msgTimes.length - 1] < 1000) precond("Slow down a little.");
    if (c.acc.lastMsg && c.acc.lastMsg.text === text && c.t - c.acc.lastMsg.at < 30000) precond("Please don't repeat the same message.");
    c.acc.msgTimes.push(c.t);
    c.acc.lastMsg = { text, at: c.t };
    c.acc.stats.messages += 1;
    if (channel === "location") {
      const loc = c.pub.location;
      if (!C.LOCATION_BY_ID[loc]) precond("You can't chat while travelling.");
      tx.set(db.collection(`locationChat/${loc}/messages`).doc(), {
        uid,
        username: c.pub.username,
        displayName: c.pub.displayName,
        text,
        at: c.t,
        expireAt: Timestamp.fromMillis(c.t + 24 * 3600000),
      });
      bump(c, "chat");
    } else {
      const [fr, ra] = extra!;
      if (!fr.exists) precond("You can only message friends.");
      if (!ra.exists || (ra.data() as Account).blocked.includes(uid)) precond("You can't message this player.");
      const pair = [uid, toUid].sort().join("_");
      tx.set(db.collection(`dms/${pair}/messages`).doc(), { from: uid, text, at: c.t });
    }
    save(tx, c);
  });
  return { ok: true };
});

// ---------------------------------------------------------------- friends / blocking / reports
async function usernameToUid(name: string): Promise<string> {
  const s = await db.doc(`usernames/${name.toLowerCase()}`).get();
  if (!s.exists) throw new HttpsError("not-found", "No player with that username.");
  return s.data()!.uid;
}

export const sendFriendRequest = onCall(async (req) => {
  const uid = uidOf(req);
  const toUid = await usernameToUid(str(req.data?.username, 3, 16, "Username"));
  if (toUid === uid) bad("That's you!");
  await db.runTransaction(async (tx) => {
    const reqRef = db.doc(`friendRequests/${uid}_${toUid}`);
    const reverse = db.doc(`friendRequests/${toUid}_${uid}`);
    const [c, fr, ex, rev, ra] = await Promise.all([
      load(tx, uid),
      tx.get(db.doc(`friends/${uid}/list/${toUid}`)),
      tx.get(reqRef),
      tx.get(reverse),
      tx.get(db.doc(`accounts/${toUid}`)),
    ]);
    if (fr.exists) precond("You're already friends.");
    if (ex.exists) precond("Request already sent.");
    if (rev.exists) precond("They already sent you a request. Check your requests.");
    if (!ra.exists || (ra.data() as Account).blocked.includes(uid)) precond("You can't send a request to this player.");
    if (c.acc.blocked.includes(toUid)) precond("Unblock this player first.");
    tx.set(reqRef, { from: uid, to: toUid, fromUsername: c.pub.username, fromDisplayName: c.pub.displayName, status: "pending", at: c.t });
    notify(tx, toUid, "friend", "New friend request", `${c.pub.username} wants to be your friend.`);
    save(tx, c);
  });
  return { ok: true };
});

export const respondFriendRequest = onCall(async (req) => {
  const uid = uidOf(req);
  const fromUid = str(req.data?.from, 5, 128, "Request");
  const accept = req.data?.accept === true;
  await db.runTransaction(async (tx) => {
    const reqRef = db.doc(`friendRequests/${fromUid}_${uid}`);
    const [r, me, other] = await Promise.all([tx.get(reqRef), tx.get(db.doc(`players/${uid}`)), tx.get(db.doc(`players/${fromUid}`))]);
    if (!r.exists) precond("That request no longer exists.");
    if (accept && other.exists && me.exists) {
      const t = Date.now();
      tx.set(db.doc(`friends/${uid}/list/${fromUid}`), { uid: fromUid, username: (other.data() as Pub).username, since: t });
      tx.set(db.doc(`friends/${fromUid}/list/${uid}`), { uid, username: (me.data() as Pub).username, since: t });
      notify(tx, fromUid, "friend", "Friend request accepted", `${(me.data() as Pub).username} is now your friend.`);
    }
    tx.delete(reqRef);
  });
  return { ok: true };
});

export const removeFriend = onCall(async (req) => {
  const uid = uidOf(req);
  const other = str(req.data?.uid, 5, 128, "Player");
  const b = db.batch();
  b.delete(db.doc(`friends/${uid}/list/${other}`));
  b.delete(db.doc(`friends/${other}/list/${uid}`));
  await b.commit();
  return { ok: true };
});

export const blockPlayer = onCall(async (req) => {
  const uid = uidOf(req);
  const target = str(req.data?.uid, 5, 128, "Player");
  const block = req.data?.block !== false;
  if (target === uid) bad("You can't block yourself.");
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    const set = new Set(c.acc.blocked);
    if (block) {
      if (set.size >= 200) precond("Block list is full.");
      set.add(target);
      tx.delete(db.doc(`friends/${uid}/list/${target}`));
      tx.delete(db.doc(`friends/${target}/list/${uid}`));
    } else set.delete(target);
    c.acc.blocked = [...set];
    save(tx, c);
  });
  return { ok: true };
});

export const reportPlayer = onCall(async (req) => {
  const uid = uidOf(req);
  const target = str(req.data?.uid, 5, 128, "Player");
  const reason = oneOf(req.data?.reason, ["Harassment", "Spam", "Cheating or exploit", "Inappropriate content", "Other"], "reason");
  const detail = optStr(req.data?.detail, 500, "Details");
  await db.runTransaction(async (tx) => {
    const c = await load(tx, uid);
    if (c.t - c.acc.lastReportAt < 20000) precond("Please wait before sending another report.");
    c.acc.lastReportAt = c.t;
    tx.set(db.collection("reports").doc(), { reporter: uid, target, reason, detail, at: c.t, status: "open" });
    save(tx, c);
  });
  return { ok: true };
});

// ---------------------------------------------------------------- administration
export const adminSetBan = onCall(async (req) => {
  const uid = uidOf(req);
  if (req.auth?.token.admin !== true) throw new HttpsError("permission-denied", "Administrators only.");
  const target = str(req.data?.uid, 5, 128, "Player");
  const banned = req.data?.banned === true;
  const reason = optStr(req.data?.reason, 200, "Reason");
  await db.doc(`accounts/${target}`).update({ banned });
  if (banned) await getAuth().revokeRefreshTokens(target);
  await db.collection("adminAudit").add({ admin: uid, action: banned ? "ban" : "unban", target, reason, at: Date.now() });
  return { ok: true };
});
