// Shared game catalog. The server (Cloud Functions) is authoritative; the client
// copy (src/catalog.ts) is generated from this file via `npm run sync-catalog`
// and is used for display only. All fares, prices and salaries are fictional
// Game Naira (G₦) values with no real-world monetary value.

export const CURRENCY = "G₦";
export const START_CASH = 5000;
export const START_BANK = 10000;
export const MAX_TRANSFER = 500000;
export const MAX_DAILY_TRANSFER = 2000000;

export type NeedKey = "hunger" | "energy" | "hygiene" | "fun" | "social" | "health";
export const NEED_KEYS: NeedKey[] = ["hunger", "energy", "hygiene", "fun", "social", "health"];
export type Needs = Record<NeedKey, number>;

export const NEED_LABELS: Record<NeedKey, string> = {
  hunger: "Hunger",
  energy: "Energy",
  hygiene: "Hygiene",
  fun: "Happiness",
  social: "Social",
  health: "Health",
};

export const DEFAULT_NEEDS: Needs = { hunger: 80, energy: 90, hygiene: 85, fun: 70, social: 60, health: 100 };

// Points lost per real minute.
export const DECAY_PER_MIN: Record<NeedKey, number> = {
  hunger: 0.3,
  energy: 0.22,
  hygiene: 0.18,
  fun: 0.25,
  social: 0.2,
  health: 0,
};

export function clamp(n: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, n));
}

export function applyDecay(needs: Needs, fromMs: number, toMs: number): Needs {
  const mins = Math.max(0, (toMs - fromMs) / 60000);
  const out = { ...needs };
  for (const k of NEED_KEYS) out[k] = clamp(needs[k] - DECAY_PER_MIN[k] * mins);
  if (out.hunger <= 0 || out.energy <= 0) out.health = clamp(needs.health - 0.4 * mins);
  else if (out.hunger > 50 && out.energy > 50) out.health = clamp(needs.health + 0.05 * mins);
  for (const k of NEED_KEYS) out[k] = Math.round(out[k] * 10) / 10;
  return out;
}

export function applyEffects(needs: Needs, fx: Partial<Needs>): Needs {
  const out = { ...needs };
  for (const k of NEED_KEYS) if (fx[k]) out[k] = clamp(out[k] + (fx[k] as number));
  return out;
}

export function levelFromXp(xp: number): number {
  return 1 + Math.floor(Math.sqrt(Math.max(0, xp) / 40));
}
export function xpForLevel(level: number): number {
  return Math.pow(Math.max(1, level) - 1, 2) * 40;
}

// ---------- World ----------
export interface Location {
  id: string;
  name: string;
  kind: string;
  blurb: string;
  x: number; // 0..100 map coordinates
  y: number;
}

export const LOCATIONS: Location[] = [
  { id: "independence-layout", name: "Independence Layout", kind: "Residential", blurb: "Leafy, upscale streets with boutiques, private schools and quiet evenings.", x: 30, y: 30 },
  { id: "gra", name: "GRA", kind: "Offices", blurb: "Wide roads, government-style offices and the busy civil registry.", x: 52, y: 22 },
  { id: "abakpa", name: "Abakpa", kind: "Busy district", blurb: "Loud, lively and always moving. Motor parks, mechanics and keke riders everywhere.", x: 80, y: 30 },
  { id: "innovation-hub", name: "Enugu Innovation Hub", kind: "Tech", blurb: "A fictional co-working space where developers and founders trade ideas over cheap coffee.", x: 45, y: 40 },
  { id: "hillside-clinic", name: "Hillside Clinic", kind: "Healthcare", blurb: "A friendly neighbourhood clinic with a long waiting bench and kind nurses.", x: 68, y: 42 },
  { id: "ogui-strip", name: "Ogui Strip", kind: "Food & nightlife", blurb: "Grills, suya spots and live music after dark.", x: 26, y: 52 },
  { id: "new-haven", name: "New Haven", kind: "Commercial", blurb: "Shops, a mart, apartments and the best signal in town.", x: 55, y: 52 },
  { id: "ogbete-market", name: "Ogbete Market", kind: "Market", blurb: "A huge open market. Bargain loudly and carry your change carefully.", x: 40, y: 64 },
  { id: "uwani", name: "Uwani", kind: "Residential", blurb: "Everyday neighbourhood life: tailors, provision stores and corner chats.", x: 62, y: 68 },
  { id: "achara-layout", name: "Achara Layout", kind: "Residential", blurb: "Growing neighbourhood with new flats and building sites.", x: 82, y: 62 },
  { id: "coal-city-park", name: "Coal City Park", kind: "Park", blurb: "Shady trees, joggers and groups of friends hanging out.", x: 20, y: 76 },
  { id: "hilltop-lookout", name: "Hilltop Lookout", kind: "Scenic spot", blurb: "A breezy viewpoint over the city. Great for thinking.", x: 14, y: 16 },
];
export const LOCATION_BY_ID: Record<string, Location> = Object.fromEntries(LOCATIONS.map((l) => [l.id, l]));
export const START_LOCATION = "uwani";

export function distance(a: string, b: string): number {
  const A = LOCATION_BY_ID[a], B = LOCATION_BY_ID[b];
  if (!A || !B) return 0;
  return Math.hypot(A.x - B.x, A.y - B.y);
}

export interface Transport {
  id: string;
  name: string;
  base: number;
  perUnit: number;
  secPerUnit: number;
  energyPerUnit: number;
  fromHour: number; // Lagos hour, inclusive
  toHour: number; // exclusive
  note: string;
}
export const TRANSPORT: Transport[] = [
  { id: "walk", name: "Walk", base: 0, perUnit: 0, secPerUnit: 1.4, energyPerUnit: 0.25, fromHour: 0, toHour: 24, note: "Free, slow and tiring." },
  { id: "keke", name: "Keke (tricycle)", base: 60, perUnit: 4, secPerUnit: 0.6, energyPerUnit: 0.05, fromHour: 5, toHour: 23, note: "Cheap and quick on short routes." },
  { id: "bus", name: "City bus", base: 40, perUnit: 2.5, secPerUnit: 0.8, energyPerUnit: 0.05, fromHour: 5, toHour: 21, note: "Cheapest ride, runs in the daytime." },
  { id: "taxi", name: "Taxi", base: 200, perUnit: 9, secPerUnit: 0.35, energyPerUnit: 0.02, fromHour: 0, toHour: 24, note: "Fast, comfortable, any hour." },
];
export const TRANSPORT_BY_ID: Record<string, Transport> = Object.fromEntries(TRANSPORT.map((t) => [t.id, t]));

export function lagosHour(ms: number): number {
  return new Date(ms + 3600000).getUTCHours();
}
export function lagosDay(ms: number): string {
  return new Date(ms + 3600000).toISOString().slice(0, 10);
}

export function tripQuote(from: string, to: string, mode: Transport) {
  const d = distance(from, to);
  return {
    cost: Math.round(mode.base + mode.perUnit * d),
    seconds: Math.max(5, Math.ceil(d * mode.secPerUnit)),
    energy: Math.round(mode.energyPerUnit * d),
  };
}

// ---------- Items ----------
export type ItemCategory = "Food" | "Drink" | "Personal" | "Clothing" | "Furniture" | "Electronics";
export interface Item {
  id: string;
  name: string;
  category: ItemCategory;
  price: number;
  emoji: string;
  blurb: string;
  effects?: Partial<Needs>;
  outfit?: string; // clothing sets avatar outfit
  sleepBonus?: number; // % extra energy when sleeping at home
  soldAt: string[];
}
export const ITEMS: Item[] = [
  { id: "jollof-plate", name: "Jollof rice plate", category: "Food", price: 1200, emoji: "🍛", blurb: "Hot, smoky and filling.", effects: { hunger: 35, fun: 3 }, soldAt: ["ogbete-market", "ogui-strip", "uwani"] },
  { id: "suya-stick", name: "Suya", category: "Food", price: 900, emoji: "🍢", blurb: "Spicy skewers with onions.", effects: { hunger: 20, fun: 6 }, soldAt: ["ogui-strip", "abakpa"] },
  { id: "akara-bread", name: "Akara and bread", category: "Food", price: 500, emoji: "🥖", blurb: "Quick breakfast.", effects: { hunger: 18 }, soldAt: ["ogbete-market", "uwani", "abakpa"] },
  { id: "fruit-bowl", name: "Fruit bowl", category: "Food", price: 700, emoji: "🍉", blurb: "Fresh and light.", effects: { hunger: 15, health: 4 }, soldAt: ["ogbete-market", "new-haven"] },
  { id: "bottled-water", name: "Bottled water", category: "Drink", price: 150, emoji: "💧", blurb: "Stay hydrated.", effects: { hunger: 2, health: 1 }, soldAt: ["ogbete-market", "uwani", "new-haven", "abakpa", "gra"] },
  { id: "zobo", name: "Zobo drink", category: "Drink", price: 250, emoji: "🥤", blurb: "Chilled hibiscus drink.", effects: { fun: 4, hunger: 3 }, soldAt: ["ogbete-market", "ogui-strip", "coal-city-park"] },
  { id: "chilled-drink", name: "Chilled soft drink", category: "Drink", price: 400, emoji: "🧃", blurb: "Fizzy and cold.", effects: { fun: 8 }, soldAt: ["ogui-strip", "new-haven", "coal-city-park"] },
  { id: "soap", name: "Bar of soap", category: "Personal", price: 400, emoji: "🧼", blurb: "Freshen up.", effects: { hygiene: 30 }, soldAt: ["ogbete-market", "uwani", "new-haven"] },
  { id: "ankara-top", name: "Ankara top", category: "Clothing", price: 6500, emoji: "👚", blurb: "Bold prints.", outfit: "ankara", soldAt: ["ogbete-market", "independence-layout"] },
  { id: "streetwear-set", name: "Streetwear set", category: "Clothing", price: 9000, emoji: "🧥", blurb: "Hoodie and clean sneakers.", outfit: "streetwear", soldAt: ["ogbete-market", "new-haven"] },
  { id: "smart-outfit", name: "Smart outfit", category: "Clothing", price: 14000, emoji: "👔", blurb: "Office-ready.", outfit: "smart", soldAt: ["new-haven", "independence-layout"] },
  { id: "agbada-set", name: "Agbada set", category: "Clothing", price: 38000, emoji: "🥻", blurb: "Ceremonial elegance.", outfit: "agbada", soldAt: ["independence-layout"] },
  { id: "gold-suit", name: "Gold-trim suit", category: "Clothing", price: 80000, emoji: "✨", blurb: "A statement piece.", outfit: "gold", soldAt: ["independence-layout"] },
  { id: "foam-mattress", name: "Foam mattress", category: "Furniture", price: 25000, emoji: "🛏️", blurb: "Sleep 15% better at home.", sleepBonus: 15, soldAt: ["ogbete-market", "new-haven"] },
  { id: "orthopedic-bed", name: "Orthopedic bed", category: "Furniture", price: 120000, emoji: "🛌", blurb: "Sleep 35% better at home.", sleepBonus: 35, soldAt: ["new-haven", "independence-layout"] },
  { id: "tv-small", name: "Flat-screen TV", category: "Electronics", price: 85000, emoji: "📺", blurb: "Unlocks Watch TV at home.", soldAt: ["new-haven", "ogbete-market"] },
  { id: "smartphone", name: "Smartphone", category: "Electronics", price: 55000, emoji: "📱", blurb: "Status symbol and a lot of memes.", soldAt: ["new-haven"] },
];
export const ITEM_BY_ID: Record<string, Item> = Object.fromEntries(ITEMS.map((i) => [i.id, i]));

// ---------- Homes ----------
export interface Home {
  id: string;
  name: string;
  locationId: string;
  weeklyRent: number;
  sleepMult: number;
  blurb: string;
}
export const HOMES: Home[] = [
  { id: "shared-room-uwani", name: "Shared room, Uwani", locationId: "uwani", weeklyRent: 4000, sleepMult: 1.0, blurb: "Basic, affordable and full of neighbours." },
  { id: "studio-achara", name: "Studio, Achara Layout", locationId: "achara-layout", weeklyRent: 9000, sleepMult: 1.1, blurb: "Your own door and your own space." },
  { id: "flat-new-haven", name: "Two-bedroom flat, New Haven", locationId: "new-haven", weeklyRent: 20000, sleepMult: 1.2, blurb: "Close to shops and the Innovation Hub." },
  { id: "duplex-independence", name: "Duplex, Independence Layout", locationId: "independence-layout", weeklyRent: 55000, sleepMult: 1.35, blurb: "Quiet, gated and impressive." },
];
export const HOME_BY_ID: Record<string, Home> = Object.fromEntries(HOMES.map((h) => [h.id, h]));
export const START_HOME = "shared-room-uwani";
export const START_RENT_DAYS = 3;

// ---------- Activities ----------
export interface Activity {
  id: string;
  name: string;
  emoji: string;
  locations?: string[];
  home?: boolean;
  needsItem?: string;
  cost: number;
  seconds: number;
  effects: Partial<Needs>;
  xp: number;
}
export const ACTIVITIES: Activity[] = [
  { id: "sleep", name: "Sleep", emoji: "😴", home: true, cost: 0, seconds: 60, effects: { energy: 55, health: 5 }, xp: 0 },
  { id: "shower", name: "Take a shower", emoji: "🚿", home: true, cost: 100, seconds: 15, effects: { hygiene: 60 }, xp: 0 },
  { id: "watch-tv", name: "Watch TV", emoji: "📺", home: true, needsItem: "tv-small", cost: 0, seconds: 30, effects: { fun: 30, energy: -3 }, xp: 1 },
  { id: "hangout-park", name: "Hang out in the park", emoji: "🌳", locations: ["coal-city-park"], cost: 0, seconds: 25, effects: { fun: 20, social: 20 }, xp: 2 },
  { id: "lookout-view", name: "Enjoy the view", emoji: "🌄", locations: ["hilltop-lookout"], cost: 0, seconds: 20, effects: { fun: 18, social: 4 }, xp: 1 },
  { id: "live-music", name: "Live music night", emoji: "🎶", locations: ["ogui-strip"], cost: 2500, seconds: 40, effects: { fun: 40, social: 25, energy: -8 }, xp: 3 },
  { id: "clinic-visit", name: "See a nurse", emoji: "🩺", locations: ["hillside-clinic"], cost: 3000, seconds: 30, effects: { health: 45 }, xp: 0 },
  { id: "tech-meetup", name: "Join a tech meetup", emoji: "💡", locations: ["innovation-hub"], cost: 0, seconds: 30, effects: { social: 25, fun: 5, energy: -5 }, xp: 5 },
];
export const ACTIVITY_BY_ID: Record<string, Activity> = Object.fromEntries(ACTIVITIES.map((a) => [a.id, a]));

// ---------- Jobs ----------
export interface Rank {
  title: string;
  pay: number; // per shift
  xpNeeded: number; // job XP to reach this rank
}
export interface Job {
  id: string;
  employer: string;
  category: string;
  locationId: string;
  reqLevel: number;
  shiftSeconds: number;
  energyCost: number;
  hungerCost: number;
  ranks: Rank[];
}
const R = (a: number, b: number, c: number, t: [string, string, string]): Rank[] => [
  { title: t[0], pay: a, xpNeeded: 0 },
  { title: t[1], pay: b, xpNeeded: 100 },
  { title: t[2], pay: c, xpNeeded: 300 },
];
export const JOBS: Job[] = [
  { id: "records-clerk", employer: "Coal City Civil Registry", category: "Office administration", locationId: "gra", reqLevel: 1, shiftSeconds: 45, energyCost: 10, hungerCost: 8, ranks: R(2500, 3300, 4400, ["Records Clerk", "Senior Clerk", "Office Supervisor"]) },
  { id: "stall-attendant", employer: "Ogbete Traders' Union", category: "Retail and sales", locationId: "ogbete-market", reqLevel: 1, shiftSeconds: 40, energyCost: 12, hungerCost: 8, ranks: R(2000, 2700, 3600, ["Stall Attendant", "Sales Lead", "Market Manager"]) },
  { id: "cashier", employer: "Coal City Mart", category: "Retail and sales", locationId: "new-haven", reqLevel: 1, shiftSeconds: 40, energyCost: 9, hungerCost: 7, ranks: R(2300, 3000, 4000, ["Cashier", "Floor Supervisor", "Store Manager"]) },
  { id: "waiter", employer: "Ogui Grill House", category: "Hospitality", locationId: "ogui-strip", reqLevel: 1, shiftSeconds: 40, energyCost: 12, hungerCost: 6, ranks: R(2200, 3000, 4200, ["Waiter", "Head Waiter", "Restaurant Manager"]) },
  { id: "site-labourer", employer: "Achara Builds Ltd", category: "Construction", locationId: "achara-layout", reqLevel: 1, shiftSeconds: 50, energyCost: 20, hungerCost: 12, ranks: R(2900, 3800, 5200, ["Site Labourer", "Foreman", "Site Engineer"]) },
  { id: "keke-rider", employer: "Abakpa Riders Association", category: "Transport", locationId: "abakpa", reqLevel: 1, shiftSeconds: 40, energyCost: 12, hungerCost: 7, ranks: R(2400, 3100, 4100, ["Keke Rider", "Route Captain", "Fleet Coordinator"]) },
  { id: "tailor", employer: "Uwani Stitch House", category: "Skilled trades", locationId: "uwani", reqLevel: 2, shiftSeconds: 45, energyCost: 10, hungerCost: 6, ranks: R(3000, 4000, 5500, ["Tailor", "Master Tailor", "Fashion Designer"]) },
  { id: "dispatcher", employer: "New Haven Transit Co.", category: "Transport", locationId: "new-haven", reqLevel: 2, shiftSeconds: 45, energyCost: 10, hungerCost: 7, ranks: R(3200, 4200, 5600, ["Dispatcher", "Depot Supervisor", "Operations Lead"]) },
  { id: "nurse-aide", employer: "Hillside Clinic", category: "Healthcare", locationId: "hillside-clinic", reqLevel: 3, shiftSeconds: 50, energyCost: 14, hungerCost: 8, ranks: R(3800, 5000, 6800, ["Nurse Aide", "Staff Nurse", "Ward Matron"]) },
  { id: "teacher", employer: "Hillcrest Academy", category: "Education", locationId: "independence-layout", reqLevel: 3, shiftSeconds: 50, energyCost: 11, hungerCost: 7, ranks: R(3600, 4800, 6400, ["Class Teacher", "Head of Department", "Vice Principal"]) },
  { id: "web-dev", employer: "Enugu Innovation Hub", category: "Technology", locationId: "innovation-hub", reqLevel: 4, shiftSeconds: 55, energyCost: 12, hungerCost: 6, ranks: R(5000, 6800, 9500, ["Junior Web Developer", "Software Engineer", "Lead Engineer"]) },
  { id: "club-dj", employer: "Ogui Night Collective", category: "Entertainment", locationId: "ogui-strip", reqLevel: 5, shiftSeconds: 55, energyCost: 16, hungerCost: 6, ranks: R(5500, 7500, 10500, ["Resident DJ", "Headline DJ", "Festival Act"]) },
];
export const JOB_BY_ID: Record<string, Job> = Object.fromEntries(JOBS.map((j) => [j.id, j]));
export const JOB_XP_PER_SHIFT = 10;
export const PLAYER_XP_PER_SHIFT = 8;

export function rankForXp(job: Job, jobXp: number): number {
  let r = 0;
  job.ranks.forEach((rk, i) => {
    if (jobXp >= rk.xpNeeded) r = i;
  });
  return r;
}

// ---------- Missions (daily) ----------
export interface Mission {
  id: string;
  title: string;
  metric: string;
  target: number;
  cash: number;
  xp: number;
}
export const DAILY_MISSIONS: Mission[] = [
  { id: "d-work", title: "Finish 3 shifts", metric: "work", target: 3, cash: 3000, xp: 30 },
  { id: "d-travel", title: "Travel to 2 places", metric: "travel", target: 2, cash: 1000, xp: 15 },
  { id: "d-chat", title: "Chat 3 times in a location", metric: "chat", target: 3, cash: 800, xp: 10 },
  { id: "d-buy", title: "Buy 2 items", metric: "buy", target: 2, cash: 1000, xp: 10 },
  { id: "d-activity", title: "Do 2 activities", metric: "activity", target: 2, cash: 1200, xp: 15 },
];
export const MISSION_BY_ID: Record<string, Mission> = Object.fromEntries(DAILY_MISSIONS.map((m) => [m.id, m]));

// ---------- Avatars ----------
export const SKIN_TONES = ["#f3d2b3", "#e0ac84", "#c68642", "#a1673b", "#7a4a2a", "#4e2e1b"];
export const HAIR_STYLES = ["Low cut", "Afro", "Braids", "Twists", "Fade", "Bald"];
export const HAIR_COLORS = ["#1a1a1a", "#3a2a1e", "#7a4a2a", "#b8860b"];
export const BASE_OUTFITS = ["casual"];
export const OUTFITS = ["casual", "ankara", "streetwear", "smart", "agbada", "gold"];
export interface AvatarCfg {
  skin: number;
  hair: number;
  hairColor: number;
  outfit: string;
}
export const DEFAULT_AVATAR: AvatarCfg = { skin: 2, hair: 0, hairColor: 0, outfit: "casual" };
export const PRESENTATIONS = ["Feminine", "Masculine", "Neutral"];
export const PERSONALITIES = ["Hustler", "Chill", "Ambitious", "Friendly", "Creative", "Studious"];
