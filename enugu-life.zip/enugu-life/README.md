# ENUGU LIFE — Live Your Enugu Story

A mobile-first multiplayer life-simulation PWA set in a fictional Enugu.
React + TypeScript + Vite client, Firebase Auth, Cloud Firestore, Cloud Functions, Firebase Hosting.

**Status: version 1. This code was written without being able to install packages or run a build in the authoring environment, so it has not been compiled or run. Expect to fix a few small errors on first build.**

## What works in this version

- Email/password + Google login, logout, password reset, unique usernames, character creation (skin, hair, outfit, personality, story)
- Persistent character: cash, bank, 6 needs that decay over real time, XP/levels
- 12 fictional Enugu locations on a tappable map, 4 transport options with fares, travel times and opening hours
- 12 jobs across 9 categories, apply → start shift → wait → collect pay, 3 ranks each with promotions
- Shops (food, drinks, clothing, furniture, electronics), inventory, use/wear items, outfits change your avatar
- Housing: starter room, rent/renew/move, sleep bonus from beds
- Bank: deposit/withdraw, player-to-player transfers with confirmation, idempotency keys, limits, ledger and receipts
- Daily missions, notifications, live location chat, friends + private messages, blocking, reporting
- Live presence (players in the same location), wealth/level leaderboards
- Admin ban function with audit log (custom claim `admin`)
- PWA manifest, icons, service worker (caches app shell only, never account data)

## Not built yet (be honest with your players)

Businesses, vehicles/garages, property purchase and furniture placement, elections, scheduled city events, relationships/dating, achievements, daily/weekly/monthly leaderboard filters, push notifications, admin dashboard UI (only the ban callable and Firestore console for now), group chats.

## One-time setup

1. Create a Firebase project in https://console.firebase.google.com. Choose the project ID **enugulife** if it's free; this gives you `enugulife.web.app`. If taken, use another ID and edit `.firebaserc`.
2. Upgrade the project to the **Blaze (pay-as-you-go)** plan. Cloud Functions require it. It has a free monthly allowance, and you can set a budget alert.
3. In the console enable: **Authentication** (Email/Password, and Google if you want it), **Firestore Database** (production mode), **Hosting**.
4. Project settings → Your apps → add a **Web app** and copy its config into `.env.local` (see `.env.example`).
5. Install tools: `npm i -g firebase-tools` then `firebase login`.

## Build and deploy

```bash
npm install
npm --prefix functions install
npm run build            # syncs the catalog, typechecks, builds the client into dist/
firebase deploy          # rules, indexes, functions, hosting
```

If the first build prints TypeScript errors, fix them (they should be small) or paste them to me.

Firestore TTL: in the console, Firestore → TTL, make sure the `expireAt` policies from `firestore.indexes.json` are active (chat messages auto-delete after 24h).

## Making yourself an admin

```bash
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
node scripts/set-admin.mjs you@example.com
```

## Local development

```bash
VITE_USE_EMULATOR=true npm run dev      # and in another terminal: firebase emulators:start
```

## How it's built (security model)

- Clients **cannot write** any game data. `firestore.rules` allows reads only (own account, own transactions, own messages) and denies all writes.
- Every state change goes through a Cloud Function that validates input, runs an atomic Firestore transaction, and writes a ledger entry. Balances, salaries, prices, fares, cooldowns and rewards are computed on the server from `functions/src/catalog.ts`.
- Transfers: debit sender and credit recipient inside one transaction; an idempotency key makes retries safe; per-transfer and daily limits apply.
- Shifts: the server records when a shift ends and refuses to pay early.
- `src/catalog.ts` is a generated display copy of `functions/src/catalog.ts` (`npm run sync-catalog`). Edit the functions copy only.

## Costs to watch

Each action is a Cloud Function call plus Firestore reads/writes. Presence heartbeats write once every 90 seconds per online player. The free tiers cover small test groups; set a Blaze budget alert before inviting many people.

## Legal

Terms and privacy text in `src/screens/Legal.tsx` is starter text only. Have it reviewed before public launch. Game Naira is virtual and has no real-world value. All places and businesses are fictional.
