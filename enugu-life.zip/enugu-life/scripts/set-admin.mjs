// Grants the admin custom claim to a user. Run on your own computer:
//   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
//   node scripts/set-admin.mjs someone@example.com
// Requires: npm i firebase-admin (already installed in functions/).
import { createRequire } from "node:module";
const require = createRequire(import.meta.url + "/../../functions/package.json");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
initializeApp();
const email = process.argv[2];
if (!email) { console.error("Usage: node scripts/set-admin.mjs <email>"); process.exit(1); }
const user = await getAuth().getUserByEmail(email);
await getAuth().setCustomUserClaims(user.uid, { admin: true });
console.log(`Admin claim set for ${email} (${user.uid}). They must sign out and in again.`);
