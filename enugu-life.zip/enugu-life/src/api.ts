import { httpsCallable } from "firebase/functions";
import { functions } from "./firebase";

export async function api<T = any>(name: string, data: Record<string, unknown> = {}): Promise<T> {
  try {
    const res = await httpsCallable(functions, name)(data);
    return res.data as T;
  } catch (e: any) {
    const msg = String(e?.message || "");
    if (!msg || msg === "internal" || msg.includes("INTERNAL")) throw new Error("Something went wrong. Please try again.");
    throw new Error(msg);
  }
}
