import { useEffect, useState, type ReactNode } from "react";
import { CURRENCY } from "./catalog";

export const fmt = (n: number) => `${CURRENCY}${Math.round(n).toLocaleString("en-NG")}`;
export const secsLeft = (until: number, now: number) => Math.max(0, Math.ceil((until - now) / 1000));
export const ago = (ms: number, now: number) => {
  const s = Math.max(0, Math.floor((now - ms) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
};

// ---- toasts
type ToastItem = { id: number; msg: string; kind: "ok" | "err" };
let listeners: ((t: ToastItem) => void)[] = [];
let counter = 0;
export function toast(msg: string, kind: "ok" | "err" = "ok") {
  const t = { id: ++counter, msg, kind };
  listeners.forEach((l) => l(t));
}
export function Toasts() {
  const [items, setItems] = useState<ToastItem[]>([]);
  useEffect(() => {
    const l = (t: ToastItem) => {
      setItems((x) => [...x.slice(-2), t]);
      setTimeout(() => setItems((x) => x.filter((i) => i.id !== t.id)), 3800);
    };
    listeners.push(l);
    return () => {
      listeners = listeners.filter((x) => x !== l);
    };
  }, []);
  return (
    <div className="toasts" aria-live="polite">
      {items.map((i) => (
        <div key={i.id} className={`toast ${i.kind}`}>
          {i.msg}
        </div>
      ))}
    </div>
  );
}

export function useAction() {
  const [busy, setBusy] = useState(false);
  const run = async (fn: () => Promise<unknown>, okMsg?: string): Promise<boolean> => {
    if (busy) return false;
    setBusy(true);
    try {
      await fn();
      if (okMsg) toast(okMsg, "ok");
      return true;
    } catch (e: any) {
      toast(e?.message || String(e), "err");
      return false;
    } finally {
      setBusy(false);
    }
  };
  return { busy, run };
}

export function Bar({ label, value, color }: { label: string; value: number; color?: string }) {
  const low = value < 25;
  return (
    <div className={`bar ${low ? "low" : ""}`}>
      <div className="bar-top">
        <span>{label}</span>
        <span>{Math.round(value)}</span>
      </div>
      <div className="bar-track" role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
        <div className="bar-fill" style={{ width: `${value}%`, background: low ? undefined : color }} />
      </div>
    </div>
  );
}

export function Card({ title, children, right }: { title?: string; children: ReactNode; right?: ReactNode }) {
  return (
    <section className="card">
      {(title || right) && (
        <header className="card-h">
          <h3>{title}</h3>
          {right}
        </header>
      )}
      {children}
    </section>
  );
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <header className="card-h">
          <h3>{title}</h3>
          <button className="btn ghost sm" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </header>
        {children}
      </div>
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="empty">{children}</p>;
}

export function Segmented<T extends string>({ value, options, onChange }: { value: T; options: { id: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="seg" role="tablist">
      {options.map((o) => (
        <button key={o.id} role="tab" aria-selected={value === o.id} className={value === o.id ? "on" : ""} onClick={() => onChange(o.id)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}
