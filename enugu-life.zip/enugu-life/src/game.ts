import { createContext, useContext } from "react";
import type { Account, Pub, Tab } from "./types";

export interface GameState {
  uid: string;
  pub: Pub;
  acc: Account; // needs already decayed to "now" for display
  now: number;
  go: (tab: Tab, opts?: { username?: string; destination?: string }) => void;
  handoff: { username?: string; destination?: string };
  clearHandoff: () => void;
  openPlayer: (uid: string) => void;
}
export const GameCtx = createContext<GameState>(null as unknown as GameState);
export const useGame = () => useContext(GameCtx);
