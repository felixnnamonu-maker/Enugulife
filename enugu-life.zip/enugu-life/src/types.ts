import type { AvatarCfg, Needs } from "./catalog";

export interface Account {
  cash: number;
  bank: number;
  needs: Needs;
  needsAt: number;
  xp: number;
  jobId: string | null;
  jobXp: number;
  shift: { endsAt: number; jobId: string } | null;
  busyUntil: number;
  busyReason: string;
  travel: { to: string; arriveAt: number } | null;
  homeId: string;
  rentPaidUntil: number;
  daily: { day: string; counts: Record<string, number>; claimed: string[] };
  stats: { shifts: number; trips: number; purchases: number; transfersSent: number; messages: number; earned: number };
  blocked: string[];
  banned: boolean;
}
export interface Pub {
  username: string;
  displayName: string;
  avatar: AvatarCfg;
  presentation: string;
  personality: string;
  bio: string;
  status: string;
  location: string;
  level: number;
  xp: number;
  netWorth: number;
  jobTitle: string | null;
  lastActive: number;
  createdAt: number;
}
export interface Txn {
  id: string;
  type: string;
  amount: number;
  participants: string[];
  from?: string | null;
  to?: string | null;
  fromUsername?: string | null;
  toUsername?: string | null;
  note?: string;
  account?: string;
  status: string;
  at: number;
}
export interface Notice {
  id: string;
  type: string;
  title: string;
  body: string;
  read: boolean;
  at: number;
}
export type Tab = "home" | "city" | "work" | "bank" | "social" | "bag" | "me";
