import { HAIR_COLORS, SKIN_TONES, type AvatarCfg } from "./catalog";

const OUTFITS: Record<string, { main: string; accent: string }> = {
  casual: { main: "#3b82a0", accent: "#2b5f77" },
  ankara: { main: "#d97706", accent: "#7c2d12" },
  streetwear: { main: "#6d28d9", accent: "#4c1d95" },
  smart: { main: "#1f2937", accent: "#f8fafc" },
  agbada: { main: "#f1ead6", accent: "#c9a227" },
  gold: { main: "#8a6d1a", accent: "#f6d365" },
};

export function Avatar({ cfg, size = 56 }: { cfg: AvatarCfg; size?: number }) {
  const skin = SKIN_TONES[cfg.skin] ?? SKIN_TONES[2];
  const hc = HAIR_COLORS[cfg.hairColor] ?? HAIR_COLORS[0];
  const o = OUTFITS[cfg.outfit] ?? OUTFITS.casual;
  const front = <path d="M31 42 C31 22 69 22 69 42 C64 33 36 33 31 42Z" fill={hc} />;
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className="avatar" role="img" aria-label="Character avatar">
      <defs>
        <clipPath id="avclip">
          <circle cx="50" cy="50" r="50" />
        </clipPath>
      </defs>
      <circle cx="50" cy="50" r="50" fill="#13392a" />
      <g clipPath="url(#avclip)">
        {cfg.hair === 1 && <circle cx="50" cy="38" r="28" fill={hc} />}
        {cfg.hair === 2 && [31, 36, 64, 69].map((x) => <rect key={x} x={x - 2} y="38" width="5" height="36" rx="2.5" fill={hc} />)}
        <path d="M12 104 C12 78 32 70 50 70 C68 70 88 78 88 104Z" fill={o.main} />
        {cfg.outfit === "smart" && (
          <>
            <path d="M42 70 L50 86 L58 70Z" fill="#f8fafc" />
            <rect x="48.5" y="76" width="3" height="14" fill="#b91c1c" />
          </>
        )}
        {cfg.outfit === "ankara" && [26, 40, 60, 74].map((x, i) => <circle key={x} cx={x} cy={88 + (i % 2) * 5} r="3" fill={o.accent} />)}
        {cfg.outfit === "agbada" && <path d="M38 70 L50 100 L62 70" stroke={o.accent} strokeWidth="4" fill="none" />}
        {cfg.outfit === "gold" && <path d="M44 70 L50 104 L56 70Z" fill={o.accent} />}
        {cfg.outfit === "streetwear" && <rect x="44" y="72" width="12" height="5" rx="2" fill={o.accent} />}
        <rect x="43" y="58" width="14" height="16" rx="5" fill={skin} />
        <ellipse cx="31" cy="46" rx="3" ry="5" fill={skin} />
        <ellipse cx="69" cy="46" rx="3" ry="5" fill={skin} />
        <ellipse cx="50" cy="45" rx="19" ry="22" fill={skin} />
        {cfg.hair === 0 && front}
        {cfg.hair === 1 && front}
        {cfg.hair === 2 && front}
        {cfg.hair === 3 && (
          <>
            {front}
            {[34, 42, 50, 58, 66].map((x, i) => (
              <circle key={x} cx={x} cy={26 - (i % 2) * 2} r="6" fill={hc} />
            ))}
          </>
        )}
        {cfg.hair === 4 && <path d="M33 38 C33 27 67 27 67 38 C62 32 38 32 33 38Z" fill={hc} />}
        <circle cx="43" cy="46" r="2.2" fill="#111" />
        <circle cx="57" cy="46" r="2.2" fill="#111" />
        <path d="M43 55 Q50 60 57 55" stroke="#3a1c10" strokeWidth="2" fill="none" strokeLinecap="round" />
      </g>
    </svg>
  );
}
