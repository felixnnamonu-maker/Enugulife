import { useEffect, useRef, useState } from "react";
import { doc, onSnapshot, type Query } from "firebase/firestore";
import { db } from "./firebase";

export function useNow(ms = 1000): number {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(id);
  }, [ms]);
  return now;
}

/** undefined = loading, null = missing document */
export function useDocData<T>(path: string | null): T | null | undefined {
  const [data, setData] = useState<T | null | undefined>(undefined);
  useEffect(() => {
    setData(undefined);
    if (!path) return;
    return onSnapshot(
      doc(db, path),
      (s) => setData(s.exists() ? (s.data() as T) : null),
      (err) => {
        console.error("doc listener", path, err);
        setData(null);
      }
    );
  }, [path]);
  return data;
}

/** Live query. `key` identifies the query; the builder runs when the key changes. */
export function useRows<T>(key: string | null, build: () => Query): (T & { id: string })[] | undefined {
  const [rows, setRows] = useState<(T & { id: string })[] | undefined>(undefined);
  const builder = useRef(build);
  builder.current = build;
  useEffect(() => {
    setRows(undefined);
    if (!key) return;
    return onSnapshot(
      builder.current(),
      (snap) => setRows(snap.docs.map((d) => ({ ...(d.data() as T), id: d.id }))),
      (err) => {
        console.error("query listener", key, err);
        setRows([]);
      }
    );
  }, [key]);
  return rows;
}
