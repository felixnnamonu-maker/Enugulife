import { useEffect, useState } from "react";
import { collection, doc, getDoc, limit, orderBy, query, where } from "firebase/firestore";
import { db } from "../firebase";
import { api } from "../api";
import { CURRENCY, MAX_DAILY_TRANSFER, MAX_TRANSFER } from "../catalog";
import { Avatar } from "../Avatar";
import { useGame } from "../game";
import { useRows } from "../hooks";
import type { Pub, Txn } from "../types";
import { Card, Empty, Modal, fmt, toast, useAction } from "../ui";
import { TxnList } from "./Home";

type Found = { uid: string; pub: Pub };

export default function Bank() {
  const g = useGame();
  const { acc, now } = g;
  const { busy, run } = useAction();
  const [amt, setAmt] = useState("");
  const [name, setName] = useState("");
  const [found, setFound] = useState<Found | null>(null);
  const [tAmt, setTAmt] = useState("");
  const [note, setNote] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [key, setKey] = useState(() => crypto.randomUUID());
  const [count, setCount] = useState(20);
  const txns = useRows<Txn>(`txn:${g.uid}:${count}`, () => query(collection(db, "transactions"), where("participants", "array-contains", g.uid), orderBy("at", "desc"), limit(count)));

  const lookup = async (n: string) => {
    const clean = n.trim().toLowerCase();
    setFound(null);
    if (clean.length < 3) return;
    try {
      const u = await getDoc(doc(db, "usernames", clean));
      if (!u.exists()) return toast("No player with that username.", "err");
      const uid = u.data().uid as string;
      if (uid === g.uid) return toast("That's you. Pick someone else.", "err");
      const p = await getDoc(doc(db, "players", uid));
      if (p.exists()) setFound({ uid, pub: p.data() as Pub });
    } catch {
      toast("Couldn't look up that player.", "err");
    }
  };

  useEffect(() => {
    if (g.handoff.username) {
      setName(g.handoff.username);
      lookup(g.handoff.username);
      g.clearHandoff();
    }
  }, [g.handoff.username]); // eslint-disable-line react-hooks/exhaustive-deps

  const n = Math.floor(Number(amt));
  const tn = Math.floor(Number(tAmt));
  const tErr = !found ? "" : !tn || tn < 1 ? "Enter an amount." : tn > MAX_TRANSFER ? `Max per transfer is ${fmt(MAX_TRANSFER)}.` : tn > acc.bank ? "More than your bank balance." : "";

  const send = async () => {
    if (!found) return;
    const ok = await run(() => api("sendMoney", { toUsername: found.pub.username, amount: tn, note, key }));
    if (ok) {
      toast(`Sent ${fmt(tn)} to @${found.pub.username}`, "ok");
      setConfirm(false); setFound(null); setName(""); setTAmt(""); setNote(""); setKey(crypto.randomUUID());
    }
  };

  return (
    <>
      <div className="bars" style={{ marginBottom: 12 }}>
        <Card title="Cash"><div style={{ fontSize: 22, fontWeight: 800 }}>{fmt(acc.cash)}</div><div className="muted small">Spend on food, fares, shops</div></Card>
        <Card title="Bank"><div style={{ fontSize: 22, fontWeight: 800 }}>{fmt(acc.bank)}</div><div className="muted small">Salaries & transfers</div></Card>
      </div>

      <Card title="Deposit / withdraw">
        <label className="field"><span>Amount ({CURRENCY})</span><input inputMode="numeric" value={amt} onChange={(e) => setAmt(e.target.value.replace(/\D/g, ""))} placeholder="e.g. 2000" /></label>
        <div className="row">
          <button className="btn grow" disabled={busy || n < 1} onClick={async () => { if (await run(() => api("bankMove", { direction: "deposit", amount: n }), "Deposited")) setAmt(""); }}>Deposit</button>
          <button className="btn gold grow" disabled={busy || n < 1} onClick={async () => { if (await run(() => api("bankMove", { direction: "withdraw", amount: n }), "Withdrawn")) setAmt(""); }}>Withdraw</button>
        </div>
      </Card>

      <Card title="Send money to a player">
        <label className="field"><span>Recipient username</span>
          <div className="row">
            <input value={name} onChange={(e) => setName(e.target.value)} autoCapitalize="none" autoCorrect="off" placeholder="username" onKeyDown={(e) => e.key === "Enter" && lookup(name)} />
            <button className="btn sm" onClick={() => lookup(name)}>Find</button>
          </div>
        </label>
        {found && (
          <>
            <div className="item"><Avatar cfg={found.pub.avatar} size={44} /><div className="grow"><div>{found.pub.displayName}</div><div className="muted small">@{found.pub.username} · Lv {found.pub.level}</div></div></div>
            <label className="field"><span>Amount ({CURRENCY}) — daily limit {fmt(MAX_DAILY_TRANSFER)}</span><input inputMode="numeric" value={tAmt} onChange={(e) => setTAmt(e.target.value.replace(/\D/g, ""))} /></label>
            <label className="field"><span>Note (optional)</span><input maxLength={80} value={note} onChange={(e) => setNote(e.target.value)} /></label>
            {tErr && tAmt && <p className="err">{tErr}</p>}
            <button className="btn block" disabled={!!tErr || !tn} onClick={() => setConfirm(true)}>Review transfer</button>
          </>
        )}
        <p className="notice">Game Naira is pretend money with no real-world value. It can't be bought, withdrawn or exchanged for real money.</p>
      </Card>

      <Card title="Transaction history">
        {txns === undefined ? <Empty>Loading…</Empty> : txns.length === 0 ? <Empty>No transactions yet.</Empty> : <TxnList rows={txns} uid={g.uid} now={now} />}
        {txns && txns.length >= count && <button className="btn ghost sm block" style={{ marginTop: 8 }} onClick={() => setCount(count + 20)}>Load more</button>}
      </Card>

      {confirm && found && (
        <Modal title="Confirm transfer" onClose={() => setConfirm(false)}>
          <p>Send <b className="gold">{fmt(tn)}</b> from your bank to <b>@{found.pub.username}</b> ({found.pub.displayName})?</p>
          {note && <p className="muted">Note: “{note}”</p>}
          <p className="muted small" style={{ margin: "8px 0" }}>This can't be undone. Double-tapping is safe: each transfer is processed once.</p>
          <div className="row"><button className="btn grow" disabled={busy} onClick={send}>{busy ? "Sending…" : "Confirm and send"}</button><button className="btn ghost" onClick={() => setConfirm(false)}>Cancel</button></div>
        </Modal>
      )}
    </>
  );
}
