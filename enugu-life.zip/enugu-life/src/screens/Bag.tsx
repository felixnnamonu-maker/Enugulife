import { useState } from "react";
import { collection, query } from "firebase/firestore";
import { db } from "../firebase";
import { api } from "../api";
import { HOMES, HOME_BY_ID, ITEMS, ITEM_BY_ID, LOCATION_BY_ID } from "../catalog";
import { useGame } from "../game";
import { useRows } from "../hooks";
import { Card, Empty, Segmented, fmt, useAction } from "../ui";

type Sub = "inv" | "shop" | "home";

export default function Bag() {
  const g = useGame();
  const { acc, pub, now } = g;
  const [sub, setSub] = useState<Sub>("inv");
  const { busy, run } = useAction();
  const [qty, setQty] = useState<Record<string, number>>({});
  const [weeks, setWeeks] = useState(1);
  const inv = useRows<{ itemId: string; qty: number }>(`inv:${g.uid}`, () => query(collection(db, `accounts/${g.uid}/inventory`)));
  const shop = ITEMS.filter((i) => i.soldAt.includes(pub.location));
  const home = HOME_BY_ID[acc.homeId];
  const rentLeft = acc.rentPaidUntil - now;

  return (
    <>
      <Segmented<Sub> value={sub} onChange={setSub} options={[{ id: "inv", label: "Inventory" }, { id: "shop", label: "Shop" }, { id: "home", label: "Home" }]} />

      {sub === "inv" && (
        <Card title="Your items">
          {inv === undefined ? <Empty>Loading…</Empty> : inv.length === 0 ? <Empty>Your bag is empty. Visit a shop (Ogbete Market is a good start).</Empty> : (
            <div className="list">
              {inv.map((r) => {
                const it = ITEM_BY_ID[r.itemId];
                if (!it) return null;
                const wearing = it.outfit && pub.avatar.outfit === it.outfit;
                const usable = !!it.effects || !!it.outfit;
                return (
                  <div key={r.id} className="item">
                    <div className="emo">{it.emoji}</div>
                    <div className="grow"><div>{it.name} {r.qty > 1 && <span className="muted">×{r.qty}</span>}</div><div className="muted small">{it.blurb}</div></div>
                    {usable ? <button className="btn sm" disabled={busy || !!wearing} onClick={() => run(() => api("useItem", { itemId: it.id }))}>{it.outfit ? (wearing ? "Wearing" : "Wear") : "Use"}</button> : <span className="pill">Active</span>}
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      )}

      {sub === "shop" && (
        <Card title={`Shop · ${pub.location === "road" ? "on the road" : LOCATION_BY_ID[pub.location].name}`}>
          {shop.length === 0 ? <Empty>No shops here. Try Ogbete Market, New Haven, Uwani, Ogui Strip or Independence Layout.</Empty> : (
            <div className="list">
              {shop.map((it) => {
                const q = qty[it.id] ?? 1;
                return (
                  <div key={it.id} className="item">
                    <div className="emo">{it.emoji}</div>
                    <div className="grow"><div>{it.name}</div><div className="muted small">{it.blurb} · {fmt(it.price)}</div></div>
                    <select aria-label="Quantity" style={{ width: 62, minHeight: 36, padding: "4px 6px" }} value={q} onChange={(e) => setQty({ ...qty, [it.id]: Number(e.target.value) })}>
                      {[1, 2, 3, 5, 10].map((n) => <option key={n}>{n}</option>)}
                    </select>
                    <button className="btn sm" disabled={busy || acc.cash < it.price * q} onClick={() => run(() => api("buyItem", { itemId: it.id, qty: q }), `Bought ${q} × ${it.name}`)}>{fmt(it.price * q)}</button>
                  </div>
                );
              })}
            </div>
          )}
          <p className="notice">Purchases use cash. Withdraw from the Bank tab if you're short.</p>
        </Card>
      )}

      {sub === "home" && (
        <>
          <Card title="Your home">
            <div style={{ fontWeight: 700 }}>{home.name}</div>
            <div className="muted">{home.blurb}</div>
            <div style={{ marginTop: 8 }} className={rentLeft > 0 ? "pos" : "err"}>{rentLeft > 0 ? `Rent paid for ${Math.ceil(rentLeft / 86400000)} more day(s)` : "Rent has expired — renew to sleep and shower at home."}</div>
            <div className="muted small">Sleeping here gives ×{home.sleepMult} energy. Beds you own add a bonus.</div>
          </Card>
          <Card title="Rent a place">
            <label className="field"><span>Weeks</span><select value={weeks} onChange={(e) => setWeeks(Number(e.target.value))}>{[1, 2, 3, 4].map((w) => <option key={w}>{w}</option>)}</select></label>
            <div className="list">
              {HOMES.map((h) => (
                <div key={h.id} className="item">
                  <div className="grow"><div>{h.name}</div><div className="muted small">{h.blurb} · {fmt(h.weeklyRent)}/week · sleep ×{h.sleepMult}</div></div>
                  <button className="btn sm" disabled={busy || acc.bank < h.weeklyRent * weeks} onClick={() => run(() => api("rentHome", { homeId: h.id, weeks }), h.id === acc.homeId ? "Rent renewed" : "You moved in!")}>{h.id === acc.homeId ? "Renew" : "Move in"} {fmt(h.weeklyRent * weeks)}</button>
                </div>
              ))}
            </div>
            <p className="notice">Rent is paid from your bank balance. Buying homes, furniture placement and visiting friends' homes are planned for a later version.</p>
          </Card>
        </>
      )}
    </>
  );
}
