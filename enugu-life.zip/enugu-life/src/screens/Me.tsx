import { useEffect, useState } from "react";
import { collection, query } from "firebase/firestore";
import { sendPasswordResetEmail, signOut } from "firebase/auth";
import { auth, db } from "../firebase";
import { api } from "../api";
import { ITEMS, OUTFITS, PERSONALITIES, type AvatarCfg } from "../catalog";
import { useGame } from "../game";
import { useDocData, useRows } from "../hooks";
import type { Pub } from "../types";
import { Card, Modal, useAction } from "../ui";
import { AvatarEditor } from "./Create";
import { Legal } from "./Legal";

function BlockedRow({ uid }: { uid: string }) {
  const p = useDocData<Pub>(`players/${uid}`);
  const { busy, run } = useAction();
  return (
    <div className="item">
      <div className="grow">@{p?.username ?? "unknown"}</div>
      <button className="btn ghost sm" disabled={busy} onClick={() => run(() => api("blockPlayer", { uid, block: false }), "Unblocked")}>Unblock</button>
    </div>
  );
}

export default function Me() {
  const g = useGame();
  const { pub, acc } = g;
  const { busy, run } = useAction();
  const [displayName, setDisplayName] = useState(pub.displayName);
  const [status, setStatus] = useState(pub.status);
  const [bio, setBio] = useState(pub.bio);
  const [personality, setPersonality] = useState(pub.personality);
  const [avatar, setAvatar] = useState<AvatarCfg>(pub.avatar);
  const [legal, setLegal] = useState(false);
  const [del, setDel] = useState(false);
  const [installEvt, setInstallEvt] = useState<any>(null);
  const inv = useRows<{ itemId: string; qty: number }>(`inv:${g.uid}`, () => query(collection(db, `accounts/${g.uid}/inventory`)));
  const owned = new Set(["casual", ...(inv ?? []).map((r) => ITEMS.find((i) => i.id === r.itemId)?.outfit).filter((o): o is string => !!o)]);

  useEffect(() => {
    const h = (e: Event) => { e.preventDefault(); setInstallEvt(e); };
    window.addEventListener("beforeinstallprompt", h);
    return () => window.removeEventListener("beforeinstallprompt", h);
  }, []);

  return (
    <>
      <Card title="Appearance">
        <AvatarEditor value={avatar} onChange={setAvatar} />
        <div className="field"><span>Outfit (buy more in shops)</span>
          <div className="chips">{OUTFITS.map((o) => <button key={o} disabled={!owned.has(o)} className={`chip ${avatar.outfit === o ? "on" : ""}`} style={{ opacity: owned.has(o) ? 1 : 0.4 }} onClick={() => setAvatar({ ...avatar, outfit: o })}>{o}</button>)}</div>
        </div>
      </Card>
      <Card title="Profile">
        <label className="field"><span>Display name</span><input maxLength={24} value={displayName} onChange={(e) => setDisplayName(e.target.value)} /></label>
        <label className="field"><span>Status message</span><input maxLength={80} value={status} onChange={(e) => setStatus(e.target.value)} placeholder="What's on your mind?" /></label>
        <div className="field"><span>Personality</span><div className="chips">{PERSONALITIES.map((p) => <button key={p} className={`chip ${personality === p ? "on" : ""}`} onClick={() => setPersonality(p)}>{p}</button>)}</div></div>
        <label className="field"><span>Background story</span><textarea maxLength={300} value={bio} onChange={(e) => setBio(e.target.value)} /></label>
        <button className="btn block" disabled={busy} onClick={() => run(() => api("updateProfile", { displayName, status, bio, personality, avatar }), "Profile saved")}>Save changes</button>
        <p className="muted small" style={{ marginTop: 8 }}>Username: @{pub.username} (can't be changed)</p>
      </Card>
      {acc.blocked.length > 0 && <Card title="Blocked players"><div className="list">{acc.blocked.map((u) => <BlockedRow key={u} uid={u} />)}</div></Card>}
      <Card title="Account">
        <p className="muted small" style={{ marginBottom: 8 }}>Signed in as {auth.currentUser?.email}</p>
        {installEvt && <button className="btn gold block" style={{ marginBottom: 8 }} onClick={async () => { installEvt.prompt(); setInstallEvt(null); }}>Install app on this device</button>}
        <p className="muted small" style={{ marginBottom: 8 }}>On iPhone: Share → Add to Home Screen.</p>
        <div className="row" style={{ flexWrap: "wrap" }}>
          <button className="btn ghost sm" onClick={() => run(async () => { if (auth.currentUser?.email) await sendPasswordResetEmail(auth, auth.currentUser.email); }, "Password reset email sent")}>Reset password</button>
          <button className="btn ghost sm" onClick={() => setLegal(true)}>Terms & privacy</button>
          <button className="btn ghost sm" onClick={() => setDel(true)}>Delete account</button>
          <button className="btn sm" onClick={() => signOut(auth)}>Log out</button>
        </div>
      </Card>
      {legal && <Modal title="Terms and Privacy" onClose={() => setLegal(false)}><Legal /></Modal>}
      {del && (
        <Modal title="Request account deletion" onClose={() => setDel(false)}>
          <p>This sends a request to delete your account and game data. It isn't instant, and it can't be undone once processed.</p>
          <div className="row" style={{ marginTop: 12 }}>
            <button className="btn danger" disabled={busy} onClick={async () => { if (await run(() => api("requestAccountDeletion"), "Deletion requested")) setDel(false); }}>Request deletion</button>
            <button className="btn ghost" onClick={() => setDel(false)}>Keep my account</button>
          </div>
        </Modal>
      )}
    </>
  );
}
