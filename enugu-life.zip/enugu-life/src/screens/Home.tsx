import { collection, limit, orderBy, query, where } from "firebase/firestore";
import { db } from "../firebase";
import { api } from "../api";
import { ACTIVITIES, DAILY_MISSIONS, HOME_BY_ID, ITEM_BY_ID, LOCATION_BY_ID, NEED_KEYS, NEED_LABELS, levelFromXp, xpForLevel } from "../catalog";
import { Avatar } from "../Avatar";
import { useGame } from "../game";
import { useRows } from "../hooks";
import type { Pub, Txn } from "../types";
import { Bar, Card, Empty, ago, fmt, useAction } from "../ui";

const LOW_HINT: Record<string, string> = {
  hunger: "You're hungry. Buy food at Ogbete Market or Ogui Strip.",
  energy: "You're tired. Go home and sleep.",
  hygiene: "You need a wash. Take a shower at home.",
  fun: "You're bored. Try the park or a live music night.",
  social: "You feel lonely. Chat with people nearby.",
  health: "Your health is low. See a nurse at Hillside Clinic.",
};
const COLORS: Record<string, string> = { hunger: "#e8a33d", energy: "#4fa3d1", hygiene: "#7fd1c8", fun: "#e57fb0", social: "#a98be8", health: "#2fb26f" };

export default function Home() {
  const g = useGame();
  const { busy, run } = useAction();
  const { pub, acc, now } = g;
  const home = HOME_BY_ID[acc.homeId];
  const loc = LOCATION_BY_ID[pub.location];
  const nextXp = xpForLevel(levelFromXp(acc.xp) + 1);
  const curXp = xpForLevel(levelFromXp(acc.xp));
  const lowNeeds = NEED_KEYS.filter((k) => acc.needs[k] < 25);

  const nearby = useRows<Pub>(pub.location === "road" ? null : `near:${pub.location}`, () => query(collection(db, "players"), where("location", "==", pub.location), limit(40)));
  const people = (nearby ?? []).filter((p) => p.id !== g.uid && now - p.lastActive < 180000 && !acc.blocked.includes(p.id));
  const txns = useRows<Txn>(`txn5:${g.uid}`, () => query(collection(db, "transactions"), where("participants", "array-contains", g.uid), orderBy("at", "desc"), limit(5)));

  const acts = ACTIVITIES.filter((a) => (a.home ? loc && home.locationId === pub.location : a.locations?.includes(pub.location)));

  return (
    <>
      <Card>
        <div className="hero">
          <Avatar cfg={pub.avatar} size={84} />
          <div className="grow">
            <div style={{ fontWeight: 800, fontSize: 18 }}>{pub.displayName}</div>
            <div className="muted">{pub.jobTitle ?? "Unemployed"} · {loc ? loc.name : "On the road"}</div>
            {pub.status && <div className="muted small">“{pub.status}”</div>}
            <div className="bar-track" style={{ marginTop: 8 }} aria-label="Level progress"><div className="bar-fill" style={{ width: `${Math.min(100, ((acc.xp - curXp) / Math.max(1, nextXp - curXp)) * 100)}%`, background: "var(--gold)" }} /></div>
            <div className="muted small">Level {pub.level} · {acc.xp - curXp}/{nextXp - curXp} XP</div>
          </div>
        </div>
      </Card>

      <Card title="Needs">
        <div className="bars">
          {NEED_KEYS.map((k) => <Bar key={k} label={NEED_LABELS[k]} value={acc.needs[k]} color={COLORS[k]} />)}
        </div>
        {lowNeeds.map((k) => <p key={k} className="err">⚠️ {LOW_HINT[k]}</p>)}
      </Card>

      {acts.length > 0 && (
        <Card title="Things to do here">
          <div className="list">
            {acts.map((a) => {
              const reason = a.home && acc.rentPaidUntil <= now ? "Rent expired" : "";
              return (
                <div key={a.id} className="item">
                  <div className="emo">{a.emoji}</div>
                  <div className="grow">
                    <div>{a.name}</div>
                    <div className="muted small">
                      {a.cost ? fmt(a.cost) : "Free"} · {a.seconds}s{a.needsItem ? ` · needs ${ITEM_BY_ID[a.needsItem].name}` : ""}
                    </div>
                  </div>
                  <button className="btn sm" disabled={busy || acc.busyUntil > now || !!reason} onClick={() => run(() => api("doActivity", { activityId: a.id }))}>{reason || "Do it"}</button>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      <Card title="Daily missions" right={<span className="muted small">Resets at midnight (Lagos)</span>}>
        <div className="list">
          {DAILY_MISSIONS.map((m) => {
            const n = Math.min(m.target, acc.daily.counts[m.metric] || 0);
            const claimed = acc.daily.claimed.includes(m.id);
            return (
              <div key={m.id} className="item">
                <div className="grow">
                  <div>{m.title}</div>
                  <div className="muted small">{n}/{m.target} · reward {fmt(m.cash)} + {m.xp} XP</div>
                </div>
                <button className="btn gold sm" disabled={busy || claimed || n < m.target} onClick={() => run(() => api("claimMission", { missionId: m.id }), "Reward claimed")}>{claimed ? "Claimed" : "Claim"}</button>
              </div>
            );
          })}
        </div>
      </Card>

      <Card title={`People here${loc ? ` · ${loc.name}` : ""}`}>
        {pub.location === "road" ? <Empty>You're on the road.</Empty> : nearby === undefined ? <Empty>Looking around…</Empty> : people.length === 0 ? <Empty>No other players are here right now.</Empty> : (
          <div className="list">
            {people.map((p) => (
              <div key={p.id} className="item" onClick={() => g.openPlayer(p.id)} style={{ cursor: "pointer" }}>
                <Avatar cfg={p.avatar} size={40} />
                <div className="grow"><div>{p.displayName}</div><div className="muted small">@{p.username} · Lv {p.level}{p.jobTitle ? ` · ${p.jobTitle}` : ""}</div></div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card title="Recent transactions" right={<button className="link" onClick={() => g.go("bank")}>All</button>}>
        {txns === undefined ? <Empty>Loading…</Empty> : txns.length === 0 ? <Empty>No transactions yet.</Empty> : <TxnList rows={txns} uid={g.uid} now={now} />}
      </Card>
    </>
  );
}

export function TxnList({ rows, uid, now }: { rows: Txn[]; uid: string; now: number }) {
  return (
    <div className="list">
      {rows.map((t) => {
        const incoming = t.to === uid && t.from !== uid ? true : t.type === "deposit" ? false : ["salary", "mission"].includes(t.type);
        const label =
          t.type === "transfer" ? (t.from === uid ? `Sent to @${t.toUsername}` : `Received from @${t.fromUsername}`) : t.type === "deposit" ? "Deposit to bank" : t.type === "withdrawal" ? "Withdrawal to cash" : t.note || t.type;
        const neutral = t.type === "deposit" || t.type === "withdrawal";
        return (
          <div key={t.id} className="item">
            <div className="grow">
              <div>{label}</div>
              <div className="muted small">{t.type}{t.type === "transfer" && t.note ? ` · “${t.note}”` : ""} · {ago(t.at, now)} · #{t.id.slice(0, 6)}</div>
            </div>
            <b className={neutral ? "" : incoming ? "pos" : "neg"}>{neutral ? "" : incoming ? "+" : "−"}{fmt(t.amount)}</b>
          </div>
        );
      })}
    </div>
  );
}
