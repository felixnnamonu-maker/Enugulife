import { useEffect, useState } from "react";
import { api } from "../api";
import { ACTIVITIES, ITEMS, JOBS, LOCATIONS, LOCATION_BY_ID, TRANSPORT, lagosHour, tripQuote } from "../catalog";
import { useGame } from "../game";
import { Card, fmt, secsLeft, useAction } from "../ui";

export default function City() {
  const g = useGame();
  const { acc, pub, now } = g;
  const here = pub.location;
  const [sel, setSel] = useState<string>(LOCATION_BY_ID[here] ? here : acc.travel?.to ?? "uwani");
  const { busy, run } = useAction();

  useEffect(() => {
    if (g.handoff.destination) {
      setSel(g.handoff.destination);
      g.clearHandoff();
    }
  }, [g.handoff.destination]); // eslint-disable-line react-hooks/exhaustive-deps

  const loc = LOCATION_BY_ID[sel];
  const hr = lagosHour(now);
  const shops = ITEMS.filter((i) => i.soldAt.includes(sel));
  const jobs = JOBS.filter((j) => j.locationId === sel);
  const acts = ACTIVITIES.filter((a) => a.locations?.includes(sel));
  const traveling = here === "road" || (acc.travel && acc.travel.arriveAt > now);

  return (
    <>
      <svg className="map" viewBox="0 0 100 100" role="group" aria-label="Map of Enugu">
        {LOCATIONS.map((a, i) => LOCATIONS.slice(i + 1).filter((b) => Math.hypot(a.x - b.x, a.y - b.y) < 24).map((b) => <line key={a.id + b.id} className="road" x1={a.x} y1={a.y} x2={b.x} y2={b.y} />))}
        {LOCATIONS.map((l) => (
          <g key={l.id} className={`node ${sel === l.id ? "sel" : ""} ${here === l.id ? "here" : ""}`} onClick={() => setSel(l.id)} role="button" tabIndex={0} aria-label={l.name} onKeyDown={(e) => e.key === "Enter" && setSel(l.id)}>
            <circle cx={l.x} cy={l.y} r={sel === l.id ? 3.6 : 2.8} />
            <text x={l.x} y={l.y + 6.6} textAnchor="middle">{l.name.length > 16 ? l.name.replace("Enugu ", "") : l.name}</text>
          </g>
        ))}
      </svg>
      <p className="muted small" style={{ margin: "6px 2px 12px" }}>Illustrated, fictional map. Gold = selected, green = where you are.</p>

      <Card title={loc.name} right={<span className="pill">{loc.kind}</span>}>
        <p className="muted">{loc.blurb}</p>
        {here === sel ? <p className="pos" style={{ marginTop: 8 }}>📍 You are here.</p> : null}
        <div className="muted small" style={{ marginTop: 10 }}>
          {shops.length > 0 && <div>🛒 Shop: {shops.length} item types for sale</div>}
          {acts.length > 0 && <div>🎯 Activities: {acts.map((a) => a.name).join(", ")}</div>}
          {jobs.length > 0 && <div>💼 Employers: {jobs.map((j) => j.employer).join(", ")}</div>}
        </div>
      </Card>

      {here !== sel && (
        <Card title="Get there">
          {traveling ? (
            <p className="muted">You're travelling{acc.travel ? ` to ${LOCATION_BY_ID[acc.travel.to].name} (${secsLeft(acc.travel.arriveAt, now)}s left)` : ""}.</p>
          ) : (
            <div className="list">
              {TRANSPORT.map((t) => {
                const q = tripQuote(here, sel, t);
                const open = hr >= t.fromHour && hr < t.toHour;
                const why = !open ? "Not running now" : acc.cash < q.cost ? "Not enough cash" : acc.needs.energy < Math.max(q.energy, 1) ? "Too tired" : acc.busyUntil > now ? "Busy" : "";
                return (
                  <div key={t.id} className="item">
                    <div className="grow">
                      <div>{t.name}</div>
                      <div className="muted small">{q.cost ? fmt(q.cost) : "Free"} · {q.seconds}s{q.energy ? ` · −${q.energy} energy` : ""} · {t.note}</div>
                    </div>
                    <button className="btn sm" disabled={busy || !!why} onClick={() => run(() => api("travel", { to: sel, mode: t.id }))}>{why || "Go"}</button>
                  </div>
                );
              })}
            </div>
          )}
          <p className="notice">Fares are fictional game prices, not real transport costs.</p>
        </Card>
      )}
      {here === sel && shops.length > 0 && <button className="btn gold block" onClick={() => g.go("bag")}>Open the shop here</button>}
    </>
  );
}
