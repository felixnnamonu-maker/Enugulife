export function Legal() {
  return (
    <div className="legal">
      <p><b>Starter text.</b> Have a lawyer review and replace this before you launch publicly.</p>
      <h4>Terms of Service</h4>
      <p>Enugu Life is an entertainment game. Game Naira (G₦) is virtual currency with no monetary value; it cannot be bought, sold, cashed out or exchanged for real money. Locations, businesses, jobs and prices are fictional and are not real-world information.</p>
      <p>Be respectful. Harassment, hate, spam, cheating, exploiting bugs and impersonation can lead to suspension. We may remove content or accounts to keep the game safe.</p>
      <h4>Privacy Policy</h4>
      <p>We store your email (for login), username, display name, avatar, in-game activity, messages and transactions so the game can work. Your email is never shown to other players. Other players can see your public profile: username, display name, avatar, level, location, status and net worth.</p>
      <p>Private messages are visible only to the two people in the chat and to administrators investigating reports. You can ask for your account to be deleted from Me &gt; Account.</p>
    </div>
  );
}
