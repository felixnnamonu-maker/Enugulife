import type { FormEvent } from "react";
import { useState } from "react";
import { createUserWithEmailAndPassword, GoogleAuthProvider, sendPasswordResetEmail, signInWithEmailAndPassword, signInWithPopup } from "firebase/auth";
import { auth } from "../firebase";
import { Modal, useAction } from "../ui";
import { Legal } from "./Legal";

type Mode = "login" | "register" | "forgot";

function friendly(code: string): string {
  const m: Record<string, string> = {
    "auth/invalid-credential": "Wrong email or password.",
    "auth/invalid-email": "That email address doesn't look right.",
    "auth/email-already-in-use": "An account with that email already exists. Try logging in.",
    "auth/weak-password": "Use a password of at least 6 characters.",
    "auth/too-many-requests": "Too many attempts. Please wait a bit and try again.",
    "auth/network-request-failed": "Network problem. Check your connection.",
    "auth/popup-closed-by-user": "Sign-in was cancelled.",
    "auth/operation-not-allowed": "This sign-in method isn't enabled yet in Firebase.",
  };
  return m[code] ?? "Something went wrong. Please try again.";
}

export default function AuthScreen() {
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [agree, setAgree] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [legal, setLegal] = useState(false);
  const { busy, run } = useAction();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setErr("");
    setMsg("");
    try {
      await (async () => {
        if (mode === "login") await signInWithEmailAndPassword(auth, email.trim(), pw);
        else if (mode === "register") {
          if (!agree) throw { code: "x", message: "Please accept the Terms and Privacy Policy." };
          await createUserWithEmailAndPassword(auth, email.trim(), pw);
        } else {
          await sendPasswordResetEmail(auth, email.trim());
          setMsg("If that email has an account, a reset link is on its way.");
        }
      })();
    } catch (ex: any) {
      setErr(ex.code === "x" ? ex.message : friendly(ex.code));
    }
  };

  const google = () => run(async () => {
    try {
      await signInWithPopup(auth, new GoogleAuthProvider());
    } catch (ex: any) {
      throw new Error(friendly(ex.code));
    }
  });

  return (
    <div className="splash" style={{ placeItems: "start center", overflowY: "auto" }}>
      <div className="auth">
        <div className="logo" style={{ textAlign: "center" }}>ENUGU LIFE</div>
        <div className="tag" style={{ textAlign: "center", marginBottom: 22 }}>Live Your Enugu Story.</div>
        <form className="card" onSubmit={submit}>
          <h3 className="gold" style={{ marginBottom: 12 }}>{mode === "login" ? "Log in" : mode === "register" ? "Create your account" : "Reset password"}</h3>
          <label className="field">
            <span>Email</span>
            <input type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          {mode !== "forgot" && (
            <label className="field">
              <span>Password</span>
              <input type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} required minLength={6} value={pw} onChange={(e) => setPw(e.target.value)} />
            </label>
          )}
          {mode === "register" && (
            <label className="row small muted" style={{ marginBottom: 10 }}>
              <input type="checkbox" style={{ width: 22, minHeight: 22 }} checked={agree} onChange={(e) => setAgree(e.target.checked)} />
              <span>
                I accept the <button type="button" className="link" onClick={() => setLegal(true)}>Terms and Privacy Policy</button>
              </span>
            </label>
          )}
          {err && <p className="err" role="alert">{err}</p>}
          {msg && <p className="pos small">{msg}</p>}
          <button className="btn block" disabled={busy}>{mode === "login" ? "Log in" : mode === "register" ? "Sign up" : "Send reset link"}</button>
          {mode !== "forgot" && (
            <button type="button" className="btn ghost block" style={{ marginTop: 8 }} onClick={google} disabled={busy}>
              Continue with Google
            </button>
          )}
          <div className="row between" style={{ marginTop: 10 }}>
            {mode === "login" ? (
              <>
                <button type="button" className="link" onClick={() => setMode("register")}>New here? Sign up</button>
                <button type="button" className="link" onClick={() => setMode("forgot")}>Forgot password?</button>
              </>
            ) : (
              <button type="button" className="link" onClick={() => setMode("login")}>Back to log in</button>
            )}
          </div>
        </form>
        <p className="notice">Enugu Life is a game. Game Naira (G₦) is pretend money with no real-world value and cannot be withdrawn. Places and businesses are fictional.</p>
      </div>
      {legal && (
        <Modal title="Terms and Privacy" onClose={() => setLegal(false)}>
          <Legal />
        </Modal>
      )}
    </div>
  );
}
