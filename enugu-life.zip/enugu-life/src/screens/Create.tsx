import type { FormEvent } from "react";
import { useState } from "react";
import { signOut } from "firebase/auth";
import { auth } from "../firebase";
import { api } from "../api";
import { DEFAULT_AVATAR, HAIR_COLORS, HAIR_STYLES, PERSONALITIES, PRESENTATIONS, SKIN_TONES, START_BANK, START_CASH, type AvatarCfg } from "../catalog";
import { Avatar } from "../Avatar";
import { fmt, useAction } from "../ui";

export function AvatarEditor({ value, onChange }: { value: AvatarCfg; onChange: (a: AvatarCfg) => void }) {
  return (
    <div>
      <div style={{ display: "grid", placeItems: "center", marginBottom: 12 }}>
        <Avatar cfg={value} size={120} />
      </div>
      <div className="field"><span>Skin tone</span>
        <div className="swatches">
          {SKIN_TONES.map((c, i) => (
            <button key={c} type="button" className={`sw ${value.skin === i ? "on" : ""}`} style={{ background: c }} aria-label={`Skin tone ${i + 1}`} onClick={() => onChange({ ...value, skin: i })} />
          ))}
        </div>
      </div>
      <div className="field"><span>Hairstyle</span>
        <div className="chips">
          {HAIR_STYLES.map((h, i) => (
            <button key={h} type="button" className={`chip ${value.hair === i ? "on" : ""}`} onClick={() => onChange({ ...value, hair: i })}>{h}</button>
          ))}
        </div>
      </div>
      <div className="field"><span>Hair colour</span>
        <div className="swatches">
          {HAIR_COLORS.map((c, i) => (
            <button key={c} type="button" className={`sw ${value.hairColor === i ? "on" : ""}`} style={{ background: c }} aria-label={`Hair colour ${i + 1}`} onClick={() => onChange({ ...value, hairColor: i })} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default function CreateCharacter() {
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [avatar, setAvatar] = useState<AvatarCfg>(DEFAULT_AVATAR);
  const [presentation, setPresentation] = useState("Neutral");
  const [personality, setPersonality] = useState("Chill");
  const [bio, setBio] = useState("");
  const { busy, run } = useAction();

  const submit = (e: FormEvent) => {
    e.preventDefault();
    run(() => api("createPlayer", { username, displayName: displayName || username, avatar, presentation, personality, bio }));
  };

  return (
    <div className="splash" style={{ placeItems: "start center", overflowY: "auto" }}>
      <form className="auth" onSubmit={submit}>
        <div className="logo" style={{ textAlign: "center" }}>CREATE YOUR CHARACTER</div>
        <p className="tag" style={{ textAlign: "center", marginBottom: 16 }}>You start in Uwani with {fmt(START_CASH)} cash and {fmt(START_BANK)} in the bank.</p>
        <div className="card">
          <label className="field"><span>Username (unique, 3-16 letters, numbers, _)</span>
            <input required minLength={3} maxLength={16} pattern="[A-Za-z][A-Za-z0-9_]{2,15}" value={username} onChange={(e) => setUsername(e.target.value)} autoCapitalize="none" autoCorrect="off" />
          </label>
          <label className="field"><span>Character name</span>
            <input maxLength={24} value={displayName} placeholder={username || "Your name in the city"} onChange={(e) => setDisplayName(e.target.value)} />
          </label>
        </div>
        <div className="card">
          <AvatarEditor value={avatar} onChange={setAvatar} />
          <div className="field"><span>Presentation</span>
            <div className="chips">{PRESENTATIONS.map((p) => <button key={p} type="button" className={`chip ${presentation === p ? "on" : ""}`} onClick={() => setPresentation(p)}>{p}</button>)}</div>
          </div>
          <div className="field"><span>Personality</span>
            <div className="chips">{PERSONALITIES.map((p) => <button key={p} type="button" className={`chip ${personality === p ? "on" : ""}`} onClick={() => setPersonality(p)}>{p}</button>)}</div>
          </div>
          <label className="field"><span>Background story (optional)</span>
            <textarea maxLength={300} value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Where do you come from? What do you want in Enugu?" />
          </label>
        </div>
        <button className="btn gold block" disabled={busy}>{busy ? "Creating…" : "Enter Enugu"}</button>
        <button type="button" className="link" style={{ display: "block", margin: "10px auto" }} onClick={() => signOut(auth)}>Log out</button>
      </form>
    </div>
  );
}
