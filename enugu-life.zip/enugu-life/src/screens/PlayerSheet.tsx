import { useGame } from "../game";
import { useDocData } from "../hooks";
import type { Pub } from "../types";
import { Avatar } from "../Avatar";
import { Modal, ago, fmt, useAction } from "../ui";
import { api } from "../api";
import { LOCATION_BY_ID } from "../catalog";
import { useState } from "react";

export function PlayerSheet({ uid, onClose }: { uid: string; onClose: () => void }) {
  const g = useGame();
  const p = useDocData<Pub>(`players/${uid}`);
  const { busy, run } = useAction();
  const [reporting, setReporting] = useState(false);
  const [reason, setReason] = useState("Harassment");
  const [detail, setDetail] = useState("");
  const isMe = uid === g.uid;
  const blocked = g.acc.blocked.includes(uid);
  const online = p ? g.now - p.lastActive < 180000 : false;

  return (
    <Modal title="Player" onClose={onClose}>
      {!p ? <p className="empty">Loading…</p> : (
        <>
          <div className="hero">
            <Avatar cfg={p.avatar} size={76} />
            <div className="grow">
              <div style={{ fontWeight: 700, fontSize: 17 }}>{p.displayName}</div>
              <div className="muted">@{p.username} · Level {p.level}</div>
              <div className="muted small">{online ? `🟢 Online · ${p.location === "road" ? "on the road" : LOCATION_BY_ID[p.location]?.name}` : `Last seen ${ago(p.lastActive, g.now)}`}</div>
            </div>
          </div>
          {p.status && <p style={{ marginTop: 10 }}>“{p.status}”</p>}
          <p className="muted" style={{ marginTop: 8 }}>{p.jobTitle ?? "Unemployed"} · {p.personality} · net worth {fmt(p.netWorth)}</p>
          {p.bio && <p className="muted small" style={{ marginTop: 6 }}>{p.bio}</p>}
          {!isMe && !reporting && (
            <div className="row" style={{ marginTop: 14, flexWrap: "wrap" }}>
              <button className="btn sm" disabled={busy || blocked} onClick={() => run(() => api("sendFriendRequest", { username: p.username }), "Friend request sent")}>Add friend</button>
              <button className="btn gold sm" onClick={() => { onClose(); g.go("bank", { username: p.username }); }}>Send G₦</button>
              <button className="btn ghost sm" disabled={busy} onClick={() => run(() => api("blockPlayer", { uid, block: !blocked }), blocked ? "Unblocked" : "Blocked")}>{blocked ? "Unblock" : "Block"}</button>
              <button className="btn ghost sm" onClick={() => setReporting(true)}>Report</button>
            </div>
          )}
          {reporting && (
            <div style={{ marginTop: 14 }}>
              <label className="field"><span>Reason</span>
                <select value={reason} onChange={(e) => setReason(e.target.value)}>
                  {["Harassment", "Spam", "Cheating or exploit", "Inappropriate content", "Other"].map((r) => <option key={r}>{r}</option>)}
                </select>
              </label>
              <label className="field"><span>Details (optional)</span><textarea maxLength={500} value={detail} onChange={(e) => setDetail(e.target.value)} /></label>
              <div className="row">
                <button className="btn danger sm" disabled={busy} onClick={async () => { if (await run(() => api("reportPlayer", { uid, reason, detail }), "Report sent. Thank you.")) onClose(); }}>Send report</button>
                <button className="btn ghost sm" onClick={() => setReporting(false)}>Cancel</button>
              </div>
            </div>
          )}
        </>
      )}
    </Modal>
  );
}
