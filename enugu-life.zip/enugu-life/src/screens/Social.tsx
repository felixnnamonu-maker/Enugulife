import type { FormEvent } from "react";
import { useEffect, useRef, useState } from "react";
import { collection, limit, orderBy, query, where } from "firebase/firestore";
import { db } from "../firebase";
import { api } from "../api";
import { LOCATION_BY_ID } from "../catalog";
import { Avatar } from "../Avatar";
import { useGame } from "../game";
import { useRows } from "../hooks";
import type { Pub } from "../types";
import { Card, Empty, Segmented, fmt, useAction } from "../ui";

type Sub = "here" | "friends" | "ranks";
interface Chat { uid: string; username: string; displayName: string; text: string; at: number }
interface Dm { from: string; text: string; at: number }
interface Friend { uid: string; username: string; since: number }
interface Req { from: string; fromUsername: string; fromDisplayName: string; at: number }

function Composer({ onSend, placeholder }: { onSend: (t: string) => Promise<boolean>; placeholder: string }) {
  const [t, setT] = useState("");
  const { busy, run } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const text = t.trim();
    if (!text) return;
    const ok = await run(() => onSend(text).then((r) => { if (!r) throw new Error("not sent"); }));
    if (ok) setT("");
  };
  return (
    <form className="row" onSubmit={submit}>
      <input value={t} maxLength={280} onChange={(e) => setT(e.target.value)} placeholder={placeholder} aria-label={placeholder} />
      <button className="btn" disabled={busy || !t.trim()}>Send</button>
    </form>
  );
}

function useStickToBottom(dep: unknown) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [dep]);
  return ref;
}

export default function Social() {
  const g = useGame();
  const [sub, setSub] = useState<Sub>("here");
  return (
    <>
      <Segmented<Sub> value={sub} onChange={setSub} options={[{ id: "here", label: "Here" }, { id: "friends", label: "Friends" }, { id: "ranks", label: "Ranks" }]} />
      {sub === "here" && <Here />}
      {sub === "friends" && <Friends />}
      {sub === "ranks" && <Ranks />}
    </>
  );
}

function Here() {
  const g = useGame();
  const loc = g.pub.location;
  const place = LOCATION_BY_ID[loc];
  const msgs = useRows<Chat>(place ? `chat:${loc}` : null, () => query(collection(db, `locationChat/${loc}/messages`), orderBy("at", "desc"), limit(50)));
  const ordered = [...(msgs ?? [])].reverse().filter((m) => !g.acc.blocked.includes(m.uid));
  const ref = useStickToBottom(ordered.length);
  const near = useRows<Pub>(place ? `near2:${loc}` : null, () => query(collection(db, "players"), where("location", "==", loc), limit(40)));
  const people = (near ?? []).filter((p) => g.now - p.lastActive < 180000 && !g.acc.blocked.includes(p.id));

  if (!place) return <Card><Empty>You're on the road. Chat opens when you arrive.</Empty></Card>;
  return (
    <>
      <Card title={`Chat · ${place.name}`} right={<span className="muted small">{people.length} online here</span>}>
        <div className="chat" ref={ref} aria-live="polite">
          {msgs === undefined ? <Empty>Loading…</Empty> : ordered.length === 0 ? <Empty>No messages yet. Say hello!</Empty> : ordered.map((m) => (
            <div key={m.id} className={`msg ${m.uid === g.uid ? "me" : ""}`}>
              <b onClick={() => g.openPlayer(m.uid)} style={{ cursor: "pointer" }}>{m.displayName || m.username}</b>{m.text}
            </div>
          ))}
        </div>
        <Composer placeholder={`Say something in ${place.name}…`} onSend={async (text) => { await api("sendMessage", { channel: "location", text }); return true; }} />
        <p className="notice">Be kind. Messages here are public to everyone in this location and are removed after 24 hours.</p>
      </Card>
      <Card title="Players here">
        {near === undefined ? <Empty>Looking around…</Empty> : people.length === 0 ? <Empty>Just you for now.</Empty> : (
          <div className="list">{people.map((p) => (
            <div key={p.id} className="item" style={{ cursor: "pointer" }} onClick={() => g.openPlayer(p.id)}>
              <Avatar cfg={p.avatar} size={40} /><div className="grow"><div>{p.displayName}{p.id === g.uid ? " (you)" : ""}</div><div className="muted small">@{p.username} · Lv {p.level}</div></div>
            </div>
          ))}</div>
        )}
      </Card>
    </>
  );
}

function Friends() {
  const g = useGame();
  const { busy, run } = useAction();
  const [name, setName] = useState("");
  const [dm, setDm] = useState<Friend | null>(null);
  const friends = useRows<Friend>(`fr:${g.uid}`, () => query(collection(db, `friends/${g.uid}/list`)));
  const reqs = useRows<Req>(`req:${g.uid}`, () => query(collection(db, "friendRequests"), where("to", "==", g.uid)));

  if (dm) return <DmView friend={dm} onBack={() => setDm(null)} />;
  return (
    <>
      <Card title="Add a friend">
        <div className="row">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="username" autoCapitalize="none" aria-label="Friend username" />
          <button className="btn" disabled={busy || name.trim().length < 3} onClick={async () => { if (await run(() => api("sendFriendRequest", { username: name.trim() }), "Friend request sent")) setName(""); }}>Add</button>
        </div>
      </Card>
      {reqs && reqs.length > 0 && (
        <Card title="Requests">
          <div className="list">{reqs.map((r) => (
            <div key={r.id} className="item">
              <div className="grow"><div>{r.fromDisplayName}</div><div className="muted small">@{r.fromUsername}</div></div>
              <button className="btn sm" disabled={busy} onClick={() => run(() => api("respondFriendRequest", { from: r.from, accept: true }), "Friend added")}>Accept</button>
              <button className="btn ghost sm" disabled={busy} onClick={() => run(() => api("respondFriendRequest", { from: r.from, accept: false }))}>Decline</button>
            </div>
          ))}</div>
        </Card>
      )}
      <Card title="Friends">
        {friends === undefined ? <Empty>Loading…</Empty> : friends.length === 0 ? <Empty>No friends yet. Meet players in a location and tap their name.</Empty> : (
          <div className="list">{friends.map((f) => (
            <div key={f.id} className="item">
              <div className="grow" onClick={() => g.openPlayer(f.uid)} style={{ cursor: "pointer" }}><div>@{f.username}</div></div>
              <button className="btn sm" onClick={() => setDm(f)}>Message</button>
              <button className="btn ghost sm" disabled={busy} onClick={() => run(() => api("removeFriend", { uid: f.uid }), "Removed")}>Remove</button>
            </div>
          ))}</div>
        )}
      </Card>
    </>
  );
}

function DmView({ friend, onBack }: { friend: Friend; onBack: () => void }) {
  const g = useGame();
  const pair = [g.uid, friend.uid].sort().join("_");
  const msgs = useRows<Dm>(`dm:${pair}`, () => query(collection(db, `dms/${pair}/messages`), orderBy("at", "desc"), limit(50)));
  const ordered = [...(msgs ?? [])].reverse();
  const ref = useStickToBottom(ordered.length);
  return (
    <Card title={`@${friend.username}`} right={<button className="btn ghost sm" onClick={onBack}>Back</button>}>
      <div className="chat" ref={ref} aria-live="polite">
        {msgs === undefined ? <Empty>Loading…</Empty> : ordered.length === 0 ? <Empty>No messages yet.</Empty> : ordered.map((m) => <div key={m.id} className={`msg ${m.from === g.uid ? "me" : ""}`}>{m.text}</div>)}
      </div>
      <Composer placeholder="Write a message…" onSend={async (text) => { await api("sendMessage", { channel: "dm", to: friend.uid, text }); return true; }} />
    </Card>
  );
}

function Ranks() {
  const g = useGame();
  const [mode, setMode] = useState<"netWorth" | "xp">("netWorth");
  const rows = useRows<Pub>(`rank:${mode}`, () => query(collection(db, "players"), orderBy(mode, "desc"), limit(20)));
  return (
    <>
      <Segmented value={mode} onChange={setMode} options={[{ id: "netWorth", label: "Wealthiest" }, { id: "xp", label: "Highest level" }]} />
      <Card title="Top 20 · all-time">
        {rows === undefined ? <Empty>Loading…</Empty> : rows.length === 0 ? <Empty>No players yet.</Empty> : (
          <div className="list">{rows.map((p, i) => (
            <div key={p.id} className="item" style={{ cursor: "pointer" }} onClick={() => g.openPlayer(p.id)}>
              <b style={{ width: 26 }} className={i < 3 ? "gold" : "muted"}>{i + 1}</b>
              <Avatar cfg={p.avatar} size={36} />
              <div className="grow"><div>{p.displayName}{p.id === g.uid ? " (you)" : ""}</div><div className="muted small">@{p.username}</div></div>
              <b>{mode === "netWorth" ? fmt(p.netWorth) : `Lv ${p.level}`}</b>
            </div>
          ))}</div>
        )}
        <p className="notice">Daily, weekly and monthly boards, business and achievement rankings are planned for a later version.</p>
      </Card>
    </>
  );
}
