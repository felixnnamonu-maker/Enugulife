import { api } from "../api";
import { JOBS, JOB_BY_ID, LOCATION_BY_ID, levelFromXp, rankForXp } from "../catalog";
import { useGame } from "../game";
import { Card, fmt, secsLeft, useAction } from "../ui";

export default function Work() {
  const g = useGame();
  const { acc, now, pub } = g;
  const { busy, run } = useAction();
  const job = acc.jobId ? JOB_BY_ID[acc.jobId] : null;
  const level = levelFromXp(acc.xp);
  const cats = [...new Set(JOBS.map((j) => j.category))];

  return (
    <>
      <Card title="Your job">
        {!job ? <p className="muted">You're unemployed. Pick a job below. Higher player levels unlock better work.</p> : (() => {
          const rank = rankForXp(job, acc.jobXp);
          const next = job.ranks[rank + 1];
          const atWork = pub.location === job.locationId;
          const onShift = acc.shift;
          const done = onShift && now >= onShift.endsAt;
          return (
            <>
              <div style={{ fontWeight: 800, fontSize: 18 }}>{job.ranks[rank].title}</div>
              <div className="muted">{job.employer} · {LOCATION_BY_ID[job.locationId].name}</div>
              <div style={{ margin: "8px 0" }}>Pay per shift: <b className="gold">{fmt(job.ranks[rank].pay)}</b> <span className="muted small">(paid to your bank account)</span></div>
              {next ? (
                <>
                  <div className="bar-track"><div className="bar-fill" style={{ width: `${Math.min(100, (acc.jobXp / next.xpNeeded) * 100)}%`, background: "var(--gold)" }} /></div>
                  <div className="muted small">Next: {next.title} ({fmt(next.pay)}/shift) at {next.xpNeeded} job XP — you have {acc.jobXp}</div>
                </>
              ) : <div className="muted small">Top rank reached 🎉</div>}
              <div className="muted small" style={{ margin: "8px 0" }}>Each shift: {job.shiftSeconds}s · uses {job.energyCost} energy and {job.hungerCost} hunger</div>
              {onShift ? (
                done ? <button className="btn gold block" disabled={busy} onClick={() => run(async () => { const r = await api<{ pay: number; promoted: boolean }>("finishShift"); return r; }, "Shift complete — salary paid to your bank")}>Collect pay</button>
                  : <button className="btn block" disabled>On shift · {secsLeft(onShift.endsAt, now)}s left</button>
              ) : atWork ? (
                <button className="btn block" disabled={busy || acc.busyUntil > now} onClick={() => run(() => api("startShift"))}>Start shift</button>
              ) : (
                <button className="btn ghost block" onClick={() => g.go("city", { destination: job.locationId })}>Travel to {LOCATION_BY_ID[job.locationId].name}</button>
              )}
              {!onShift && <button className="link" disabled={busy} onClick={() => run(() => api("quitJob"), "You quit your job")}>Quit job</button>}
            </>
          );
        })()}
      </Card>

      {cats.map((c) => (
        <Card key={c} title={c}>
          <div className="list">
            {JOBS.filter((j) => j.category === c).map((j) => {
              const locked = level < j.reqLevel;
              const mine = acc.jobId === j.id;
              return (
                <div key={j.id} className="item">
                  <div className="grow">
                    <div>{j.ranks[0].title} <span className="muted small">→ {j.ranks[2].title}</span></div>
                    <div className="muted small">{j.employer} · {LOCATION_BY_ID[j.locationId].name}</div>
                    <div className="muted small">{fmt(j.ranks[0].pay)}–{fmt(j.ranks[2].pay)}/shift · needs level {j.reqLevel}</div>
                  </div>
                  <button className="btn sm" disabled={busy || locked || mine || !!acc.shift} onClick={() => run(() => api("applyForJob", { jobId: j.id }), "You got the job!")}>{mine ? "Current" : locked ? `Lv ${j.reqLevel}` : "Apply"}</button>
                </div>
              );
            })}
          </div>
        </Card>
      ))}
      <p className="notice">Entrepreneurship, businesses and vehicle ownership are planned for a later version.</p>
    </>
  );
}
