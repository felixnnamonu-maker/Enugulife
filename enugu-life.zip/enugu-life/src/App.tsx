import { useEffect, useMemo, useRef, useState } from "react";
import { onAuthStateChanged, type User } from "firebase/auth";
import { collection, doc, limit, orderBy, query, updateDoc, writeBatch } from "firebase/firestore";
import { auth, configured, db } from "./firebase";
import { api } from "./api";
import { applyDecay, LOCATION_BY_ID } from "./catalog";
import { GameCtx } from "./game";
import { useDocData, useNow, useRows } from "./hooks";
import type { Account, Notice, Pub, Tab } from "./types";
import { Avatar } from "./Avatar";
import { fmt, Modal, Toasts, secsLeft, ago, Empty } from "./ui";
import AuthScreen from "./screens/Auth";
import CreateCharacter from "./screens/Create";
import Home from "./screens/Home";
import City from "./screens/City";
import Work from "./screens/Work";
import Bank from "./screens/Bank";
import Social from "./screens/Social";
import Bag from "./screens/Bag";
import Me from "./screens/Me";
import { PlayerSheet } from "./screens/PlayerSheet";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "home", label: "Home", icon: "🏠" },
  { id: "city", label: "City", icon: "🗺️" },
  { id: "work", label: "Work", icon: "💼" },
  { id: "bank", label: "Bank", icon: "🏦" },
  { id: "social", label: "Social", icon: "💬" },
  { id: "bag", label: "Bag", icon: "🎒" },
  { id: "me", label: "Me", icon: "👤" },
];

export default function App() {
  const [user, setUser] = useState<User | null | undefined>(undefined);
  useEffect(() => onAuthStateChanged(auth, setUser), []);

  if (!configured)
    return (
      <div className="splash">
        <div className="auth">
          <div className="logo">ENUGU LIFE</div>
          <p className="muted" style={{ marginTop: 14 }}>
            Firebase isn't configured yet. Copy <code>.env.example</code> to <code>.env.local</code>, fill in your Firebase web app keys, and rebuild.
          </p>
        </div>
      </div>
    );
  if (user === undefined)
    return (
      <div className="splash">
        <div>
          <div className="logo">ENUGU LIFE</div>
          <div className="tag">Live Your Enugu Story.</div>
        </div>
      </div>
    );
  return (
    <>
      {user ? <Authed user={user} /> : <AuthScreen />}
      <Toasts />
    </>
  );
}

function Authed({ user }: { user: User }) {
  const pub = useDocData<Pub>(`players/${user.uid}`);
  if (pub === undefined)
    return (
      <div className="splash">
        <div className="logo">ENUGU LIFE</div>
      </div>
    );
  if (pub === null) return <CreateCharacter />;
  return <Game uid={user.uid} pub={pub} />;
}

function Game({ uid, pub }: { uid: string; pub: Pub }) {
  const rawAcc = useDocData<Account>(`accounts/${uid}`);
  const [tab, setTab] = useState<Tab>("home");
  const [handoff, setHandoff] = useState<{ username?: string; destination?: string }>({});
  const [bell, setBell] = useState(false);
  const [viewUid, setViewUid] = useState<string | null>(null);
  const now = useNow(1000);

  // presence + settle travel
  useEffect(() => {
    api("heartbeat").catch(() => undefined);
    const id = setInterval(() => api("heartbeat").catch(() => undefined), 90000);
    return () => clearInterval(id);
  }, []);
  const settled = useRef<number>(0);
  useEffect(() => {
    if (rawAcc?.travel && now >= rawAcc.travel.arriveAt && settled.current !== rawAcc.travel.arriveAt) {
      settled.current = rawAcc.travel.arriveAt;
      api("heartbeat").catch(() => undefined);
    }
  }, [now, rawAcc?.travel]);

  const notices = useRows<Notice>(`notes:${uid}`, () => query(collection(db, `notifications/${uid}/items`), orderBy("at", "desc"), limit(30)));
  const unread = (notices ?? []).filter((n) => !n.read).length;

  const acc = useMemo(() => (rawAcc ? { ...rawAcc, needs: applyDecay(rawAcc.needs, rawAcc.needsAt, now) } : null), [rawAcc, now]);
  if (!acc) return <div className="splash"><div className="logo">ENUGU LIFE</div></div>;
  if (acc.banned)
    return (
      <div className="splash">
        <div className="auth">
          <div className="logo">ENUGU LIFE</div>
          <p style={{ marginTop: 12 }}>This account has been suspended. Contact support if you believe this is a mistake.</p>
        </div>
      </div>
    );

  const here = pub.location === "road" ? "On the road" : LOCATION_BY_ID[pub.location]?.name ?? pub.location;
  const state = {
    uid,
    pub,
    acc,
    now,
    handoff,
    go: (t: Tab, opts?: { username?: string; destination?: string }) => {
      setHandoff(opts ?? {});
      setTab(t);
    },
    clearHandoff: () => setHandoff({}),
    openPlayer: (u: string) => setViewUid(u),
  };

  const markAll = async () => {
    const b = writeBatch(db);
    (notices ?? []).filter((n) => !n.read).forEach((n) => b.update(doc(db, `notifications/${uid}/items/${n.id}`), { read: true }));
    await b.commit().catch(() => undefined);
  };

  return (
    <GameCtx.Provider value={state}>
      <div className="app">
        <header className="topbar">
          <Avatar cfg={pub.avatar} size={42} />
          <div className="who">
            <div className="name">{pub.displayName}</div>
            <div className="sub">
              @{pub.username} · Lv {pub.level} · {here}
            </div>
          </div>
          <div className="money">
            <b>{fmt(acc.cash)}</b>
            bank {fmt(acc.bank)}
          </div>
          <button className="bell" aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`} onClick={() => setBell(true)}>
            🔔{unread > 0 && <i>{unread}</i>}
          </button>
        </header>
        <main className="content">
          {acc.busyUntil > now && (
            <div className="banner">
              <span>⏳ {acc.busyReason}</span>
              <b>{secsLeft(acc.busyUntil, now)}s</b>
            </div>
          )}
          {tab === "home" && <Home />}
          {tab === "city" && <City />}
          {tab === "work" && <Work />}
          {tab === "bank" && <Bank />}
          {tab === "social" && <Social />}
          {tab === "bag" && <Bag />}
          {tab === "me" && <Me />}
        </main>
        <nav className="nav" aria-label="Main">
          {TABS.map((t) => (
            <button key={t.id} className={tab === t.id ? "on" : ""} onClick={() => state.go(t.id)} aria-current={tab === t.id ? "page" : undefined}>
              <span>{t.icon}</span>
              {t.label}
            </button>
          ))}
        </nav>
        {bell && (
          <Modal title="Notifications" onClose={() => setBell(false)}>
            {notices === undefined ? <Empty>Loading…</Empty> : notices.length === 0 ? <Empty>Nothing yet. Go make some moves.</Empty> : (
              <>
                <button className="btn ghost sm" onClick={markAll} style={{ marginBottom: 8 }}>Mark all read</button>
                <div className="list">
                  {notices.map((n) => (
                    <div key={n.id} className="item" onClick={() => !n.read && updateDoc(doc(db, `notifications/${uid}/items/${n.id}`), { read: true }).catch(() => undefined)}>
                      <div className="grow">
                        <div style={{ fontWeight: n.read ? 400 : 700 }}>{n.title}</div>
                        <div className="muted">{n.body}</div>
                      </div>
                      <span className="muted small">{ago(n.at, now)}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </Modal>
        )}
        {viewUid && <PlayerSheet uid={viewUid} onClose={() => setViewUid(null)} />}
      </div>
    </GameCtx.Provider>
  );
}

